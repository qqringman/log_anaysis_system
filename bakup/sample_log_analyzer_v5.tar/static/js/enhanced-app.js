// 全域變數
let currentPath = '/home/vince_lin/Rust_Project';
let selectedFiles = [];
let droppedFiles = [];
let keywords = {};
let allSelectMode = false;
let currentAnalysisId = null;
let eventSource = null;
let audioContext = null;
let analysisModal = null;
let pageHistory = [];
let currentViewMode = 'module'; // 'module' 或 'file'

// 頁面載入時初始化
$(document).ready(function() {
    console.log('🚀 Enhanced Log 分析平台載入完成');
    
    savePageState();
    addCustomStyles();
    initializeApp();
    setupEventListeners();
    setupDropAnalysis();
    loadDirectory(currentPath);
    
    try {
        analysisModal = new bootstrap.Modal(document.getElementById('analysisModal'), {
            backdrop: 'static',
            keyboard: false
        });
        console.log('✅ 模態框初始化成功');
    } catch (e) {
        console.error('❌ 模態框初始化失敗:', e);
    }
    
    setupModalButtonEvents();
    setupKeyboardShortcuts();
    
    console.log('✅ 初始化完成');
});

function savePageState() {
    const state = {
        url: window.location.href,
        timestamp: Date.now(),
        selectedFiles: selectedFiles,
        currentPath: currentPath,
        scrollPosition: window.scrollY
    };
    
    pageHistory.push(state);
    
    if (pageHistory.length > 10) {
        pageHistory.shift();
    }
    
    console.log('💾 頁面狀態已儲存');
}

function setupDropAnalysis() {
    console.log('🎯 設置拖曳分析功能');
    
    const dropZone = document.getElementById('drop-analysis-zone');
    const quickAnalysisFile = document.getElementById('quick-analysis-file');
    
    // 拖曳區域事件
    dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('drag-over');
    });
    
    dropZone.addEventListener('dragleave', function(e) {
        e.preventDefault();
        if (!dropZone.contains(e.relatedTarget)) {
            $(this).removeClass('drag-over');
        }
    });
    
    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        $(this).removeClass('drag-over');
        
        const files = Array.from(e.dataTransfer.files);
        handleDroppedFiles(files);
    });
    
    // 檔案選擇器事件
    quickAnalysisFile.addEventListener('change', function() {
        const files = Array.from(this.files);
        handleDroppedFiles(files);
    });
    
    // 選項變更事件
    $('#include-browser-files, #include-dropped-files').on('change', updateAnalysisCount);
    
    console.log('✅ 拖曳分析功能設置完成');
}

function handleDroppedFiles(files) {
    console.log('📁 處理拖曳檔案:', files.length, '個');
    
    const validExtensions = ['.log', '.txt', '.out', '.err'];
    const validFiles = files.filter(file => {
        const extension = '.' + file.name.split('.').pop().toLowerCase();
        return validExtensions.includes(extension);
    });
    
    if (validFiles.length === 0) {
        showAlert('⚠️ 請拖曳有效的日誌檔案 (.log, .txt, .out, .err)', 'warning');
        return;
    }
    
    // 將檔案轉換為臨時路徑進行分析
    validFiles.forEach(file => {
        // 檢查是否已存在
        const exists = droppedFiles.some(f => f.name === file.name && f.size === file.size);
        if (!exists) {
            // 創建一個虛擬路徑，稍後在分析時處理
            const virtualPath = `/tmp/uploaded/${file.name}`;
            droppedFiles.push({
                name: file.name,
                size: file.size,
                lastModified: file.lastModified,
                file: file,
                virtualPath: virtualPath
            });
            
            // 同時加入到已選擇檔案中供統一分析
            selectedFiles.push(virtualPath);
        }
    });
    
    updateDroppedFilesList();
    updateAnalysisCount();
    updateSelectedCount(); // 重要：更新選擇計數
    
    showAlert(`✅ 已添加 ${validFiles.length} 個檔案到分析列表`, 'success');
}

function updateDroppedFilesList() {
    const container = $('#dropped-files-container');
    const listElement = $('#dropped-files-list');
    
    if (droppedFiles.length === 0) {
        listElement.hide();
        return;
    }
    
    listElement.show();
    container.empty();
    
    droppedFiles.forEach((fileInfo, index) => {
        const fileElement = $(`
            <div class="dropped-file-item" data-index="${index}">
                <div class="d-flex align-items-center">
                    <div class="file-icon log-file me-3">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="mb-1">${fileInfo.name}</h6>
                        <small class="text-muted">
                            ${formatFileSize(fileInfo.size)} • 
                            ${new Date(fileInfo.lastModified).toLocaleString()}
                        </small>
                    </div>
                    <button class="btn btn-outline-danger btn-sm" onclick="removeDroppedFile(${index})">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `);
        
        container.append(fileElement);
    });
}

function removeDroppedFile(index) {
    const removedFile = droppedFiles[index];
    // 從已選擇檔案中移除
    selectedFiles = selectedFiles.filter(f => f !== removedFile.virtualPath);
    
    droppedFiles.splice(index, 1);
    updateDroppedFilesList();
    updateAnalysisCount();
    updateSelectedCount();
}

function clearDroppedFiles() {
    // 從已選擇檔案中移除所有拖曳檔案
    droppedFiles.forEach(fileInfo => {
        selectedFiles = selectedFiles.filter(f => f !== fileInfo.virtualPath);
    });
    
    droppedFiles = [];
    updateDroppedFilesList();
    updateAnalysisCount();
    updateSelectedCount();
    showAlert('🗑️ 已清空拖曳檔案列表', 'info');
}

function updateAnalysisCount() {
    const includeBrowser = $('#include-browser-files').is(':checked');
    const includeDropped = $('#include-dropped-files').is(':checked');
    
    // 計算瀏覽器選擇的檔案（排除拖曳檔案）
    const browserFiles = selectedFiles.filter(f => !f.startsWith('/tmp/uploaded/'));
    const browserCount = includeBrowser ? browserFiles.length : 0;
    const droppedCount = includeDropped ? droppedFiles.length : 0;
    const totalCount = browserCount + droppedCount;
    
    $('#browser-files-count').text(browserCount);
    $('#dropped-files-count').text(droppedCount);
    $('#total-files-count').text(totalCount);
    
    // 更新快速分析按鈕
    const quickAnalyzeBtn = $('#quick-analyze-btn');
    const hasKeywords = Object.keys(keywords).length > 0;
    const hasFiles = totalCount > 0;
    
    quickAnalyzeBtn.prop('disabled', !hasKeywords || !hasFiles);
    
    if (!hasKeywords) {
        quickAnalyzeBtn.html('<i class="fas fa-exclamation-triangle me-2"></i>請先上傳關鍵字');
    } else if (!hasFiles) {
        quickAnalyzeBtn.html('<i class="fas fa-folder-open me-2"></i>請選擇檔案');
    } else {
        quickAnalyzeBtn.html(`<i class="fas fa-rocket me-2"></i>分析 ${totalCount} 個檔案`);
    }
}

function startQuickAnalysis() {
    console.log('⚡ 開始快速分析');
    
    const includeBrowser = $('#include-browser-files').is(':checked');
    const includeDropped = $('#include-dropped-files').is(':checked');
    
    // 準備分析檔案列表
    let analysisFiles = [];
    
    if (includeBrowser) {
        const browserFiles = selectedFiles.filter(f => !f.startsWith('/tmp/uploaded/'));
        analysisFiles = analysisFiles.concat(browserFiles);
    }
    
    if (includeDropped) {
        const droppedPaths = droppedFiles.map(f => f.virtualPath);
        analysisFiles = analysisFiles.concat(droppedPaths);
    }
    
    if (analysisFiles.length === 0) {
        showAlert('⚠️ 請選擇要分析的檔案', 'warning');
        return;
    }
    
    // 更新全域選擇檔案列表並開始分析
    const originalSelectedFiles = selectedFiles.slice(); // 備份原始選擇
    selectedFiles = analysisFiles;
    
    startStreamAnalysis();
    
    // 恢復原始選擇（保持瀏覽器狀態）
    setTimeout(() => {
        selectedFiles = originalSelectedFiles;
    }, 1000);
}

function updateSelectedCount() {
    // 計算實際的瀏覽器選擇檔案（排除拖曳檔案）
    const browserFiles = selectedFiles.filter(f => !f.startsWith('/tmp/uploaded/'));
    $('#selected-count').text(browserFiles.length);
    
    const analyzeBtn = $('#analyze-btn');
    const totalFiles = selectedFiles.length; // 包含拖曳檔案
    
    if (totalFiles > 0 && Object.keys(keywords).length > 0) {
        analyzeBtn.prop('disabled', false);
    } else {
        analyzeBtn.prop('disabled', true);
    }
    
    // 同時更新快速分析計數
    updateAnalysisCount();
    
    console.log('📊 已選擇檔案數量:', totalFiles);
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function setupModalButtonEvents() {
    // 停止分析按鈕
    $(document).off('click', '#stop-analysis-btn').on('click', '#stop-analysis-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('🛑 停止分析按鈕被點擊');
        stopStreamAnalysis();
    });
    
    // 關閉按鈕
    $(document).off('click', '#close-analysis-btn').on('click', '#close-analysis-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('🚪 關閉按鈕被點擊');
        
        if (currentAnalysisId) {
            if (confirm('分析正在進行中，確定要關閉嗎？這將停止分析。')) {
                stopStreamAnalysis();
            }
        } else {
            if (analysisModal) {
                analysisModal.hide();
            }
        }
    });
    
    console.log('✅ 模態框按鈕事件已綁定');
}

function initializeApp() {
    console.log('🔧 初始化應用...');
    
    // 初始化音頻上下文
    try {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
        console.log('⚠️ 音頻上下文初始化失敗，音效將不可用');
    }
    
    // 載入已有的關鍵字
    $.get('/api/keywords')
        .done(function(data) {
            console.log('📋 載入關鍵字:', data);
            if (Object.keys(data).length > 0) {
                keywords = data;
                updateKeywordPreview();
            }
        })
        .fail(function() {
            console.log('❌ 載入關鍵字失敗');
        });
}

function setupEventListeners() {
    console.log('🎛️ 設置事件監聽器...');
    
    // 檔案上傳
    $('#keyword-file').on('change', function() {
        const file = this.files[0];
        if (file) {
            console.log('📁 選擇檔案:', file.name);
            uploadKeywords(file);
        }
    });
    
    // 拖拽上傳
    const uploadZone = document.getElementById('upload-zone');
    if (uploadZone) {
        uploadZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            $(this).addClass('dragover');
        });
        
        uploadZone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            $(this).removeClass('dragover');
        });
        
        uploadZone.addEventListener('drop', function(e) {
            e.preventDefault();
            $(this).removeClass('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                uploadKeywords(files[0]);
            }
        });
    }
    
    // 路徑輸入框 Enter 鍵
    $('#path-input').on('keypress', function(e) {
        if (e.which === 13) {
            navigateToPath();
        }
    });
    
    console.log('✅ 事件監聽器設置完成');
}

function setupKeyboardShortcuts() {
    // Ctrl + Enter 開始分析
    $(document).keydown(function(e) {
        if (e.ctrlKey && e.which === 13) {
            e.preventDefault();
            if (!$('#analyze-btn').prop('disabled')) {
                startStreamAnalysis();
            }
        }
        
        // Esc 停止分析
        if (e.which === 27 && currentAnalysisId) {
            e.preventDefault();
            if (confirm('確定要停止分析嗎？')) {
                stopStreamAnalysis();
            }
        }
        
        // Ctrl + N 切換導航
        if (e.ctrlKey && e.which === 78) {
            e.preventDefault();
            toggleNavigation();
        }
        
        // Ctrl + T 切換檢視模式
        if (e.ctrlKey && e.which === 84) {
            e.preventDefault();
            toggleViewMode();
        }
    });
}

function uploadKeywords(file) {
    if (!file) {
        console.log('❌ 沒有選擇檔案');
        return;
    }
    
    console.log('📤 上傳關鍵字檔案:', file.name);
    
    const formData = new FormData();
    formData.append('file', file);
    
    showAlert('📤 上傳中...', 'info');
    
    $.ajax({
        url: '/api/upload_keywords',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            console.log('📋 上傳回應:', response);
            if (response.success) {
                keywords = response.keywords;
                updateKeywordPreview();
                showAlert(`✅ ${response.message}`, 'success');
                playNotificationSound('success');
            } else {
                showAlert(`❌ ${response.message}`, 'danger');
            }
        },
        error: function(xhr, status, error) {
            console.error('❌ 上傳失敗:', status, error);
            showAlert('❌ 上傳失敗', 'danger');
        }
    });
}

function updateKeywordPreview() {
    const preview = $('#keyword-preview');
    const modules = $('#keyword-modules');
    
    if (Object.keys(keywords).length === 0) {
        preview.hide();
        return;
    }
    
    modules.empty();
    for (const [module, keywordList] of Object.entries(keywords)) {
        const moduleElement = $(`
            <div class="keyword-module animate__animated animate__fadeIn">
                <strong>${module}:</strong> ${keywordList.join(', ')}
            </div>
        `);
        modules.append(moduleElement);
    }
    
    preview.show();
    console.log('📋 關鍵字預覽已更新');
}

function loadDirectory(path) {
    console.log('📂 載入目錄:', path);
    
    $('#file-list').html(`
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">載入中...</span>
            </div>
            <p class="mt-3 text-muted">載入檔案列表中...</p>
        </div>
    `);
    
    $.get('/api/browse', { path: path })
        .done(function(response) {
            console.log('📂 目錄載入回應:', response);
            
            if (response.error) {
                $('#file-list').html(`
                    <div class="text-center py-5">
                        <i class="fas fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                        <p class="text-muted">${response.error}</p>
                        <button class="btn btn-primary" onclick="loadDirectory('${currentPath}')">重試</button>
                    </div>
                `);
                return;
            }
            
            currentPath = response.current_path;
            $('#path-input').val(currentPath);
            updateBreadcrumb();
            renderFileList(response.items);
        })
        .fail(function(xhr, status, error) {
            console.error('❌ 載入目錄失敗:', status, error);
            $('#file-list').html(`
                <div class="text-center py-5">
                    <i class="fas fa-wifi fa-3x text-danger mb-3"></i>
                    <p class="text-muted">載入失敗，請檢查網路連接</p>
                    <button class="btn btn-primary" onclick="loadDirectory('${currentPath}')">重試</button>
                </div>
            `);
        });
}

function renderFileList(items) {
    console.log('📋 渲染檔案列表:', items.length, '個項目');
    
    const fileList = $('#file-list');
    fileList.empty();
    
    if (items.length === 0) {
        fileList.html(`
            <div class="text-center py-5">
                <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                <p class="text-muted">此目錄為空</p>
            </div>
        `);
        return;
    }
    
    items.forEach(function(item, index) {
        // 排除拖曳檔案來檢查選擇狀態
        const isSelected = selectedFiles.filter(f => !f.startsWith('/tmp/uploaded/')).includes(item.path);
        
        const fileItem = $(`
            <div class="file-item ${isSelected ? 'selected' : ''}" data-path="${item.path}" data-type="${item.type}">
                <div class="d-flex align-items-center">
                    ${item.type === 'file' && !item.is_parent ? 
                        `<input type="checkbox" class="form-check-input me-3" ${isSelected ? 'checked' : ''}>` : 
                        '<div class="me-3" style="width: 16px;"></div>'
                    }
                    <div class="file-icon ${item.is_parent ? 'parent' : item.type === 'directory' ? 'directory' : 'log-file'}">
                        <i class="fas ${item.is_parent ? 'fa-arrow-left' : item.type === 'directory' ? 'fa-folder' : 'fa-file-alt'}"></i>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="mb-1">${item.name}</h6>
                        <small class="text-muted">
                            ${item.size ? item.size + ' • ' : ''}${item.modified}
                        </small>
                    </div>
                </div>
            </div>
        `);
        
        // 點擊事件
        fileItem.on('click', function(e) {
            console.log('👆 點擊項目:', item.name, item.type);
            
            if (item.type === 'directory') {
                loadDirectory(item.path);
            } else if (item.type === 'file' && !item.is_parent) {
                if (e.target.type !== 'checkbox') {
                    const checkbox = $(this).find('input[type="checkbox"]');
                    checkbox.prop('checked', !checkbox.prop('checked'));
                    checkbox.trigger('change');
                }
            }
        });
        
        // 檔案選擇事件
        const checkbox = fileItem.find('input[type="checkbox"]');
        checkbox.on('change', function(e) {
            e.stopPropagation();
            
            const path = item.path;
            const isChecked = $(this).is(':checked');
            
            console.log('☑️ 檔案選擇狀態改變:', path, isChecked);
            
            if (isChecked) {
                if (!selectedFiles.includes(path)) {
                    selectedFiles.push(path);
                }
                fileItem.addClass('selected');
            } else {
                selectedFiles = selectedFiles.filter(f => f !== path);
                fileItem.removeClass('selected');
            }
            
            updateSelectedCount();
        });
        
        fileList.append(fileItem);
    });
    
    console.log('✅ 檔案列表渲染完成');
}

function updateBreadcrumb() {
    const breadcrumb = $('#breadcrumb');
    const pathParts = currentPath.split('/').filter(part => part);
    
    breadcrumb.empty();
    
    // 根目錄
    const rootItem = $(`<li class="breadcrumb-item"><a href="#" onclick="loadDirectory('/')">根目錄</a></li>`);
    breadcrumb.append(rootItem);
    
    // 路徑部分
    let buildPath = '';
    pathParts.forEach((part, index) => {
        buildPath += '/' + part;
        const isLast = index === pathParts.length - 1;
        
        if (isLast) {
            breadcrumb.append(`<li class="breadcrumb-item active">${part}</li>`);
        } else {
            const pathToNavigate = buildPath;
            breadcrumb.append(`<li class="breadcrumb-item"><a href="#" onclick="loadDirectory('${pathToNavigate}')">${part}</a></li>`);
        }
    });
    
    console.log('🧭 面包屑導航已更新:', currentPath);
}

function navigateToPath() {
    const path = $('#path-input').val().trim();
    if (path) {
        console.log('🎯 導航到路徑:', path);
        loadDirectory(path);
    }
}

function refreshBrowser() {
    console.log('🔄 刷新瀏覽器');
    loadDirectory(currentPath);
}

function toggleSelectAll() {
    allSelectMode = !allSelectMode;
    console.log('🔄 切換全選模式:', allSelectMode);
    
    $('.file-item[data-type="file"]').each(function() {
        const checkbox = $(this).find('input[type="checkbox"]');
        const path = $(this).data('path');
        
        if (allSelectMode) {
            checkbox.prop('checked', true);
            $(this).addClass('selected');
            if (!selectedFiles.includes(path)) {
                selectedFiles.push(path);
            }
        } else {
            checkbox.prop('checked', false);
            $(this).removeClass('selected');
            selectedFiles = selectedFiles.filter(f => f !== path);
        }
    });
    
    updateSelectedCount();
    
    // 更新按鈕文字
    const btn = $('button[onclick="toggleSelectAll()"]');
    if (allSelectMode) {
        btn.html('<i class="fas fa-times me-1"></i>取消全選');
    } else {
        btn.html('<i class="fas fa-check-square me-1"></i>全選');
    }
}

function startStreamAnalysis() {
    console.log('🚀 開始流式分析');
    
    if (selectedFiles.length === 0) {
        showAlert('⚠️ 請選擇要分析的檔案', 'warning');
        return;
    }
    
    if (Object.keys(keywords).length === 0) {
        showAlert('⚠️ 請先上傳關鍵字清單', 'warning');
        return;
    }
    
    // 直接開始分析，不顯示模態框，讓用戶可以繼續操作
    initializeStreamingAnalysis();
    
    // 啟動流式分析
    $.ajax({
        url: '/api/analyze_stream',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            files: selectedFiles
        }),
        success: function(response) {
            console.log('🎯 流式分析啟動:', response);
            if (response.success) {
                currentAnalysisId = response.analysis_id;
                startEventSource(response.analysis_id);
                showAlert('🚀 分析已開始，結果將即時顯示在下方！', 'success');
                playNotificationSound('start');
                
                // 更新分析按鈕狀態
                updateAnalysisButtonState('running');
            } else {
                showAlert(`❌ ${response.message}`, 'danger');
                updateAnalysisButtonState('idle');
            }
        },
        error: function(xhr, status, error) {
            console.error('❌ 啟動分析失敗:', status, error);
            showAlert('❌ 啟動分析失敗，請檢查網路連接', 'danger');
            updateAnalysisButtonState('idle');
        }
    });
}

function initializeStreamingAnalysis() {
    const resultsContainer = $('#analysis-results');
    const statsContainer = $('#result-stats');
    const detailsContainer = $('#detailed-results');
    
    // 顯示分析區域
    resultsContainer.show();
    
    // 初始化統計區域，包含停止按鈕
    statsContainer.html(`
        <div class="col-md-2">
            <div class="card bg-primary text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-file-alt"></i>檔案</h5>
                    <h2 id="stat-files" class="counter-number">${selectedFiles.length}</h2>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card bg-success text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-cube"></i>模組</h5>
                    <h2 id="stat-modules" class="counter-number">0/${Object.keys(keywords).length}</h2>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card bg-info text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-search"></i>匹配</h5>
                    <h2 id="stat-matches" class="counter-number">0</h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-cogs"></i>進度</h5>
                    <div class="progress progress-modern mb-2">
                        <div class="progress-bar progress-bar-animated" id="progress-bar" style="width: 0%"></div>
                    </div>
                    <small id="progress-text" class="progress-text">準備中...</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-secondary text-white stats-card">
                <div class="card-body text-center">
                    <h5 class="icon-no-wrap"><i class="fas fa-clock"></i>狀態</h5>
                    <div id="analysis-status-display">
                        <div class="d-flex align-items-center justify-content-center">
                            <div class="spinner-border spinner-border-sm me-2" role="status" id="status-spinner"></div>
                            <span id="current-module-display">初始化中...</span>
                        </div>
                        <button class="btn btn-danger btn-sm mt-2" id="stop-analysis-inline" onclick="stopStreamAnalysis()">
                            <i class="fas fa-stop me-1"></i>停止分析
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    // 初始化結果區域
    detailsContainer.html(`
        <div id="view-controls" class="view-controls mb-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5><i class="fas fa-eye me-2"></i>檢視模式</h5>
                </div>
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-primary ${currentViewMode === 'module' ? 'active' : ''}" 
                            onclick="setViewMode('module')">
                        <i class="fas fa-cube me-1"></i>按模組
                    </button>
                    <button type="button" class="btn btn-outline-primary ${currentViewMode === 'file' ? 'active' : ''}" 
                            onclick="setViewMode('file')">
                        <i class="fas fa-file me-1"></i>按檔案
                    </button>
                </div>
            </div>
        </div>
        <div id="stream-results" class="stream-results">
            <div class="analysis-starting animate__animated animate__fadeIn">
                <div class="text-center py-4">
                    <div class="d-flex align-items-center justify-content-center mb-3">
                        <div class="spinner-border text-primary me-3" role="status"></div>
                        <h5 class="mb-0">正在啟動分析引擎...</h5>
                    </div>
                    <p class="text-muted">結果將在下方即時顯示，您可以繼續操作其他功能</p>
                </div>
            </div>
        </div>
    `);
    
    // 滾動到結果區域
    $('html, body').animate({
        scrollTop: resultsContainer.offset().top - 50
    }, 300);
}

function updateAnalysisButtonState(state) {
    const analyzeBtn = $('#analyze-btn');
    
    switch (state) {
        case 'running':
            analyzeBtn.html('<i class="fas fa-spinner fa-spin me-2"></i>分析進行中')
                      .removeClass('btn-danger-gradient')
                      .addClass('btn-warning')
                      .prop('disabled', false)
                      .attr('onclick', 'stopStreamAnalysis()');
            break;
        case 'stopping':
            analyzeBtn.html('<i class="fas fa-circle-notch fa-spin me-2"></i>正在停止')
                      .addClass('btn-secondary')
                      .prop('disabled', true);
            break;
        case 'idle':
        default:
            analyzeBtn.html('<i class="fas fa-stream me-2"></i>開始流式分析')
                      .removeClass('btn-warning btn-secondary')
                      .addClass('btn-danger-gradient')
                      .prop('disabled', selectedFiles.length === 0 || Object.keys(keywords).length === 0)
                      .attr('onclick', 'startStreamAnalysis()');
            break;
    }
}

function startEventSource(analysisId) {
    console.log('🌊 啟動 EventSource:', analysisId);
    
    // 關閉現有連接
    if (eventSource) {
        eventSource.close();
        eventSource = null;
    }
    
    try {
        // 建立新的 SSE 連接
        eventSource = new EventSource(`/api/analysis_stream/${analysisId}`);
        
        eventSource.onmessage = function(event) {
            try {
                const data = JSON.parse(event.data);
                // 使用 setTimeout 確保不阻塞 UI
                setTimeout(() => {
                    handleStreamMessage(data);
                }, 0);
            } catch (e) {
                console.error('❌ 解析 SSE 訊息失敗:', e, event.data);
            }
        };
        
        eventSource.onerror = function(event) {
            console.error('❌ EventSource 錯誤:', event);
            console.log('EventSource readyState:', eventSource?.readyState);
            
            // 如果連接關閉，清理資源
            if (!eventSource || eventSource.readyState === EventSource.CLOSED) {
                console.log('🔌 EventSource 連接已關閉');
                eventSource = null;
            }
        };
        
        eventSource.onopen = function(event) {
            console.log('✅ EventSource 連接已建立');
        };
        
    } catch (e) {
        console.error('❌ 建立 EventSource 失敗:', e);
        showAlert('❌ 建立即時連接失敗', 'danger');
    }
}

function handleStreamMessage(data) {
    try {
        console.log('📩 收到流式訊息:', data.type);
        
        switch (data.type) {
            case 'heartbeat':
                // 心跳訊息，保持連接
                break;
                
            case 'start':
                requestAnimationFrame(() => {
                    updateProgressStatus('🚀 分析開始', '正在初始化...');
                    // 移除啟動訊息
                    $('.analysis-starting').remove();
                });
                break;
                
            case 'module_start':
                requestAnimationFrame(() => {
                    updateProgressStatus(`🔍 分析模組: ${data.module}`, '準備搜尋關鍵字...');
                });
                break;
                
            case 'file_start':
                requestAnimationFrame(() => {
                    updateProgressStatus(`📂 分析檔案: ${data.module}`, `正在處理: ${data.file.split('/').pop()}`);
                });
                break;
                
            case 'matches_found':
                // 使用 requestAnimationFrame 確保不阻塞UI
                requestAnimationFrame(() => {
                    handleMatchesFound(data);
                });
                break;
                
            case 'progress':
                requestAnimationFrame(() => {
                    updateProgress(data.progress);
                });
                break;
                
            case 'module_complete':
                requestAnimationFrame(() => {
                    updateModuleComplete(data);
                });
                break;
                
            case 'complete':
                requestAnimationFrame(() => {
                    handleAnalysisComplete(data);
                });
                break;
                
            case 'error':
            case 'timeout':
                requestAnimationFrame(() => {
                    handleAnalysisError(data);
                });
                break;
                
            default:
                console.log('🤔 未知訊息類型:', data.type);
        }
    } catch (e) {
        console.error('❌ 處理流式訊息時發生錯誤:', e, data);
    }
}

function handleMatchesFound(data) {
    try {
        console.log('🎯 發現匹配 - 模組:', data.module, '檔案:', data.file.split('/').pop(), '匹配數:', data.matches.length);
        
        // 更新統計
        updateStatsLightweight(data.total_matches);
        
        // 根據當前檢視模式更新結果
        if (currentViewMode === 'module') {
            updateModuleViewResults(data);
        } else {
            updateFileViewResults(data);
        }
        
    } catch (e) {
        console.error('❌ 處理匹配結果時發生錯誤:', e, data);
    }
}

function updateModuleViewResults(data) {
    const streamResults = $('#stream-results');
    const moduleId = data.module.replace(/\s+/g, '-');
    
    // 查找或創建模組元素
    let moduleElement = $(`#module-view-${moduleId}`);
    if (moduleElement.length === 0) {
        moduleElement = createModuleViewElement(data.module, moduleId);
        streamResults.append(moduleElement);
    }
    
    // 更新模組內容
    updateModuleViewContent(moduleElement, data);
}

function updateFileViewResults(data) {
    const streamResults = $('#stream-results');
    const fileName = data.file.split('/').pop();
    const fileId = fileName.replace(/[^\w]/g, '-');
    
    // 查找或創建檔案元素
    let fileElement = $(`#file-view-${fileId}`);
    if (fileElement.length === 0) {
        fileElement = createFileViewElement(fileName, data.file, fileId);
        streamResults.append(fileElement);
    }
    
    // 更新檔案內容
    updateFileViewContent(fileElement, data);
}

function createModuleViewElement(module, moduleId) {
    return $(`
        <div class="result-module animate__animated animate__fadeInLeft" id="module-view-${moduleId}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <h4 class="icon-no-wrap">
                        <i class="fas fa-cube"></i>${module}
                        <span class="analysis-progress-icon ms-2" id="module-progress-${moduleId}">
                            <i class="fas fa-spinner fa-spin text-warning"></i>
                        </span>
                    </h4>
                    <p class="mb-3" id="module-info-${moduleId}">
                        <span class="icon-no-wrap">
                            <i class="fas fa-search"></i>找到 <span class="match-count">0</span> 次匹配
                        </span>
                        <span class="ms-3 analysis-status-text">
                            <span class="icon-no-wrap">
                                <i class="fas fa-clock"></i>分析中...
                            </span>
                        </span>
                    </p>
                </div>
                <div class="module-controls">
                    <button class="btn btn-back-to-top btn-sm" onclick="scrollToTop()" title="回到頂部">
                        <span class="icon-no-wrap">
                            <i class="fas fa-arrow-up"></i>頂部
                        </span>
                    </button>
                </div>
            </div>
            
            <!-- 檔案導航 -->
            <div class="module-file-navigation mb-3" id="module-file-nav-${moduleId}" style="display: none;">
                <div class="file-nav-header">
                    <h6 class="icon-no-wrap">
                        <i class="fas fa-folder-open"></i>包含檔案
                        <span class="badge bg-secondary ms-2" id="file-count-${moduleId}">0</span>
                    </h6>
                </div>
                <div class="file-nav-buttons" id="file-nav-buttons-${moduleId}">
                    <!-- 檔案導航按鈕將在這裡動態添加 -->
                </div>
            </div>
            
            <div id="module-files-${moduleId}" class="module-files">
                <!-- 檔案結果將在這裡顯示 -->
            </div>
        </div>
    `);
}

function createFileViewElement(fileName, filePath, fileId) {
    return $(`
        <div class="result-file-view animate__animated animate__fadeInLeft" id="file-view-${fileId}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <h4 class="icon-no-wrap">
                        <i class="fas fa-file"></i>${fileName}
                        <span class="analysis-progress-icon ms-2" id="file-progress-${fileId}">
                            <i class="fas fa-spinner fa-spin text-warning"></i>
                        </span>
                    </h4>
                    <p class="mb-3" id="file-info-${fileId}">
                        <small class="text-muted">${filePath}</small>
                        <span class="ms-3">
                            <i class="fas fa-search me-1"></i>找到 <span class="match-count">0</span> 次匹配
                        </span>
                    </p>
                </div>
                <div class="file-controls">
                    <a href="/view_file?path=${encodeURIComponent(filePath)}&line=1" 
                       class="btn btn-outline-primary btn-sm me-2" target="_blank" title="檢視檔案">
                        <i class="fas fa-external-link-alt"></i>
                    </a>
                    <button class="btn btn-back-to-top btn-sm" onclick="scrollToTop()" title="回到頂部">
                        <span class="icon-no-wrap">
                            <i class="fas fa-arrow-up"></i>頂部
                        </span>
                    </button>
                </div>
            </div>
            
            <!-- 模組導航 -->
            <div class="file-module-navigation mb-3" id="file-module-nav-${fileId}" style="display: none;">
                <div class="module-nav-header">
                    <h6 class="icon-no-wrap">
                        <i class="fas fa-cube"></i>相關模組
                        <span class="badge bg-secondary ms-2" id="module-count-${fileId}">0</span>
                    </h6>
                </div>
                <div class="module-nav-buttons" id="module-nav-buttons-${fileId}">
                    <!-- 模組導航按鈕將在這裡動態添加 -->
                </div>
            </div>
            
            <div id="file-modules-${fileId}" class="file-modules">
                <!-- 模組結果將在這裡顯示 -->
            </div>
        </div>
    `);
}

function updateModuleViewContent(moduleElement, data) {
    const moduleId = data.module.replace(/\s+/g, '-');
    const filesContainer = $(`#module-files-${moduleId}`);
    
    // 更新匹配數量
    const matchCount = moduleElement.find('.match-count');
    const oldCount = parseInt(matchCount.text()) || 0;
    const newCount = data.total_matches;
    
    if (newCount > oldCount) {
        animateNumber(matchCount, newCount);
    }
    
    // 查找或創建檔案元素
    const fileId = data.file.replace(/[^\w]/g, '-');
    let fileElement = filesContainer.find(`#file-${moduleId}-${fileId}`);
    
    if (fileElement.length === 0) {
        fileElement = createModuleFileElement(data, moduleId, fileId);
        filesContainer.append(fileElement);
        
        // 更新檔案導航
        updateModuleFileNavigation(moduleId, data.file, data.module);
    }
    
    // 添加新的匹配到檔案中
    updateModuleFileContent(fileElement, data);
}

function updateFileViewContent(fileElement, data) {
    const fileName = data.file.split('/').pop();
    const fileId = fileName.replace(/[^\w]/g, '-');
    const modulesContainer = $(`#file-modules-${fileId}`);
    
    // 更新匹配數量
    const matchCount = fileElement.find('.match-count');
    const oldCount = parseInt(matchCount.text()) || 0;
    
    // 累加新匹配數
    const newCount = oldCount + data.matches.length;
    animateNumber(matchCount, newCount);
    
    // 查找或創建模組元素
    const moduleId = data.module.replace(/[^\w]/g, '-');
    let moduleElement = modulesContainer.find(`#module-${fileId}-${moduleId}`);
    
    if (moduleElement.length === 0) {
        moduleElement = createFileModuleElement(data, fileId, moduleId);
        modulesContainer.append(moduleElement);
        
        // 更新模組導航
        updateFileModuleNavigation(fileId, data.module, fileName);
    }
    
    // 添加新的匹配到模組中
    updateFileModuleContent(moduleElement, data);
}

function createModuleFileElement(data, moduleId, fileId) {
    const fileName = data.file.split('/').pop();
    
    return $(`
        <div class="result-file animate__animated animate__fadeInUp" id="file-${moduleId}-${fileId}">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="flex-grow-1">
                    <h6 class="mb-1">
                        <a href="/view_file?path=${encodeURIComponent(data.file)}&line=1" 
                           class="file-path-link" target="_blank" title="檢視完整檔案">
                            <span class="icon-no-wrap">
                                <i class="fas fa-file"></i>${fileName}
                            </span>
                        </a>
                    </h6>
                    <small class="text-muted">${data.file}</small>
                    <span class="badge bg-light text-dark ms-2 file-match-count">0 條匹配</span>
                </div>
                <button class="btn btn-back-to-top btn-sm" onclick="scrollToModule('${data.module}')" title="回到模組頂部">
                    <span class="icon-no-wrap">
                        <i class="fas fa-arrow-up"></i>模組
                    </span>
                </button>
            </div>
            <div class="keyword-groups" id="keyword-groups-${moduleId}-${fileId}">
                <!-- 關鍵字分組將在這裡顯示 -->
            </div>
        </div>
    `);
}

function createFileModuleElement(data, fileId, moduleId) {
    return $(`
        <div class="result-module-in-file animate__animated animate__fadeInUp" id="module-${fileId}-${moduleId}">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="flex-grow-1">
                    <h6 class="mb-1">
                        <span class="icon-no-wrap">
                            <i class="fas fa-cube"></i>${data.module}
                        </span>
                    </h6>
                    <span class="badge bg-light text-dark module-match-count">0 條匹配</span>
                </div>
                <button class="btn btn-back-to-top btn-sm" onclick="scrollToTop()" title="回到頂部">
                    <span class="icon-no-wrap">
                        <i class="fas fa-arrow-up"></i>頂部
                    </span>
                </button>
            </div>
            <div class="keyword-groups" id="keyword-groups-${fileId}-${moduleId}">
                <!-- 關鍵字分組將在這裡顯示 -->
            </div>
        </div>
    `);
}

function updateModuleFileContent(fileElement, data) {
    const moduleId = data.module.replace(/\s+/g, '-');
    const fileId = data.file.replace(/[^\w]/g, '-');
    
    // 更新檔案匹配計數
    const fileMatchCount = fileElement.find('.file-match-count');
    const currentTotal = parseInt(fileMatchCount.text().match(/\d+/)?.[0] || 0) + data.matches.length;
    fileMatchCount.text(`${currentTotal} 條匹配`);
    
    // 處理關鍵字組
    updateKeywordGroups(fileElement, data, `keyword-groups-${moduleId}-${fileId}`);
}

function updateFileModuleContent(moduleElement, data) {
    const fileId = data.file.split('/').pop().replace(/[^\w]/g, '-');
    const moduleId = data.module.replace(/\s+/g, '-');
    
    // 更新模組匹配計數
    const moduleMatchCount = moduleElement.find('.module-match-count');
    const currentTotal = parseInt(moduleMatchCount.text().match(/\d+/)?.[0] || 0) + data.matches.length;
    moduleMatchCount.text(`${currentTotal} 條匹配`);
    
    // 處理關鍵字組
    updateKeywordGroups(moduleElement, data, `keyword-groups-${fileId}-${moduleId}`);
}

function updateKeywordGroups(parentElement, data, containerId) {
    const keywordGroupsContainer = parentElement.find(`#${containerId}`);
    
    // 查找或創建關鍵字組
    const keywordId = data.keyword.replace(/\s+/g, '-');
    let keywordGroup = keywordGroupsContainer.find(`#keyword-group-${containerId}-${keywordId}`);
    
    if (keywordGroup.length === 0) {
        keywordGroup = createKeywordGroup(data, containerId, keywordId);
        keywordGroupsContainer.append(keywordGroup);
    }
    
    // 添加匹配行到關鍵字組
    const keywordContent = keywordGroup.find('.keyword-content');
    data.matches.forEach(match => {
        const lineElement = createMatchLineElement(match, data.file);
        keywordContent.append(lineElement);
    });
    
    // 更新關鍵字組計數
    const existingCount = keywordContent.find('.result-line').length;
    keywordGroup.find('.keyword-count').text(`${existingCount} 條`);
}

function createKeywordGroup(data, containerId, keywordId) {
    return $(`
        <div class="keyword-group animate__animated animate__fadeInRight" id="keyword-group-${containerId}-${keywordId}">
            <div class="keyword-header" onclick="toggleKeywordGroup('${containerId}-${keywordId}')">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="keyword-tag">${data.keyword}</span>
                        <span class="badge bg-primary ms-2 keyword-count">0 條</span>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <button class="btn btn-outline-primary btn-sm smart-analysis-btn" 
                                onclick="event.stopPropagation(); openSmartAnalysis('${data.module}', '${data.keyword}', '${data.file}')" 
                                title="AI智能分析">
                            <span class="icon-no-wrap">
                                <i class="fas fa-brain"></i>智能分析
                            </span>
                        </button>
                        <i class="fas fa-chevron-down keyword-toggle"></i>
                    </div>
                </div>
            </div>
            <div class="keyword-content">
                <!-- 匹配行將在這裡顯示 -->
            </div>
        </div>
    `);
}

function createMatchLineElement(match, filePath) {
    const highlightedContent = highlightKeyword(match.content, match.keyword);
    
    return $(`
        <div class="result-line animate__animated animate__fadeIn">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <small class="text-muted mb-1">
                        <a href="/view_file?path=${encodeURIComponent(filePath)}&line=${match.line_number}" 
                           class="line-number-link" target="_blank" title="跳轉到第 ${match.line_number} 行">
                            <span class="icon-no-wrap">
                                <i class="fas fa-map-marker-alt"></i>第 ${match.line_number} 行
                            </span>
                        </a>
                    </small>
                    <div class="line-content">${highlightedContent}</div>
                </div>
            </div>
        </div>
    `);
}

function toggleKeywordGroup(groupId) {
    const group = $(`#keyword-group-${groupId}`);
    group.toggleClass('collapsed');
    
    const toggle = group.find('.keyword-toggle');
    if (group.hasClass('collapsed')) {
        toggle.removeClass('fa-chevron-down').addClass('fa-chevron-right');
    } else {
        toggle.removeClass('fa-chevron-right').addClass('fa-chevron-down');
    }
}

function setViewMode(mode) {
    if (currentViewMode === mode) return;
    
    currentViewMode = mode;
    
    // 更新按鈕狀態
    $('#view-controls .btn').removeClass('active');
    $(`#view-controls .btn[onclick="setViewMode('${mode}')"]`).addClass('active');
    
    // 清空當前結果並重新組織
    $('#stream-results').html('<div class="text-center py-4"><p class="text-muted">切換檢視模式中...</p></div>');
    
    showAlert(`🔄 已切換到${mode === 'module' ? '模組' : '檔案'}檢視模式`, 'info');
}

function toggleViewMode() {
    const newMode = currentViewMode === 'module' ? 'file' : 'module';
    setViewMode(newMode);
}

function updateStatsLightweight(totalMatches) {
    // 輕量級統計更新，減少DOM操作
    const statsElement = $('#stat-matches');
    if (statsElement.length > 0) {
        const currentValue = parseInt(statsElement.text()) || 0;
        if (totalMatches > currentValue) {
            statsElement.text(totalMatches);
        }
    }
}

function updateProgressStatus(moduleText, fileText) {
    $('#current-module-display').html(`
        <div class="small">${moduleText}</div>
        <div class="text-muted" style="font-size: 0.75rem;">${fileText}</div>
    `);
    $('#progress-text').text('分析中...');
}

function updateProgress(progress) {
    $('#progress-bar').css('width', progress + '%');
    $('#progress-text').text(`${progress}% 完成`);
}

function updateModuleComplete(data) {
    const moduleId = data.module.replace(/\s+/g, '-');
    
    // 移除進度圖示
    $(`#module-progress-${moduleId}, #file-progress-${moduleId}`).html('<i class="fas fa-check-circle text-success"></i>');
    
    // 更新完成模組計數
    const completedModules = $('.fa-check-circle.text-success').length;
    animateNumber('#stat-modules', `${completedModules}/${Object.keys(keywords).length}`);
}

function handleAnalysisComplete(data) {
    console.log('🎉 分析完成:', data);
    
    // 關閉 EventSource
    if (eventSource) {
        eventSource.close();
        eventSource = null;
    }
    
    // 移除所有進度圖示
    $('.analysis-progress-icon').html('<i class="fas fa-check-circle text-success"></i>');
    
    // 更新統計
    animateNumber('#stat-modules', `${Object.keys(keywords).length}/${Object.keys(keywords).length}`);
    $('#progress-bar').css('width', '100%');
    $('#progress-text').text('100% 完成');
    $('#current-module-display').html('<div class="text-success"><i class="fas fa-check-circle me-2"></i>分析完成</div>');
    
    // 隱藏停止按鈕
    $('#stop-analysis-inline').hide();
    
    // 創建快速導航
    createQuickNavigation();
    
    // 顯示浮動導航按鈕
    $('#floating-nav-btn').show();
    
    // 播放完成音效
    playNotificationSound('complete');
    
    // 顯示完成訊息
    showAlert(`🎉 分析完成！總共找到 ${data.total_matches || 0} 次匹配，耗時 ${data.total_time?.toFixed(2) || 0} 秒`, 'success');
    
    // 重置分析按鈕
    updateAnalysisButtonState('idle');
    
    // 清理分析狀態
    currentAnalysisId = null;
}

function handleAnalysisError(data) {
    console.error('❌ 分析錯誤:', data);
    
    // 關閉 EventSource
    if (eventSource) {
        eventSource.close();
        eventSource = null;
    }
    
    // 更新狀態顯示
    $('#current-module-display').html('<div class="text-danger"><i class="fas fa-exclamation-triangle me-2"></i>分析錯誤</div>');
    $('#stop-analysis-inline').hide();
    
    // 顯示錯誤訊息
    showAlert(`❌ 分析過程中發生錯誤：${data.message || '未知錯誤'}`, 'danger');
    
    // 重置分析按鈕
    updateAnalysisButtonState('idle');
    
    // 清理分析狀態
    currentAnalysisId = null;
}

function stopStreamAnalysis() {
    console.log('⏹️ 手動停止分析，當前分析ID:', currentAnalysisId);
    
    try {
        // 關閉 EventSource
        if (eventSource) {
            console.log('🔌 關閉 EventSource 連接');
            eventSource.close();
            eventSource = null;
        }
        
        // 清理分析資料
        if (currentAnalysisId) {
            console.log('🧹 清理分析資料:', currentAnalysisId);
            $.ajax({
                url: `/api/analysis_cleanup/${currentAnalysisId}`,
                method: 'DELETE',
                timeout: 5000
            }).done(function(response) {
                console.log('✅ 分析資料清理完成:', response);
            }).fail(function(xhr, status, error) {
                console.error('❌ 清理分析資料失敗:', status, error);
            });
            
            currentAnalysisId = null;
        }
        
        // 更新UI狀態
        updateProgressStatus('⏹️ 分析已停止', '用戶手動停止分析');
        $('#stop-analysis-inline').hide();
        updateAnalysisButtonState('idle');
        
        showAlert('⏹️ 分析已手動停止', 'warning');
        
    } catch (e) {
        console.error('❌ 停止分析時發生錯誤:', e);
        showAlert('❌ 停止分析時發生錯誤', 'danger');
    }
}

function createQuickNavigation() {
    const quickNav = $('#quick-navigation');
    const moduleNavButtons = $('#module-nav-buttons');
    
    // 清空現有導航
    moduleNavButtons.empty();
    
    // 根據當前檢視模式創建不同的導航
    if (currentViewMode === 'module') {
        $('#stream-results .result-module').each(function() {
            const moduleTitle = $(this).find('h4').text().trim();
            const matchCount = $(this).find('.match-count').text();
            
            const moduleBtn = $(`
                <button class="btn nav-btn nav-btn-module btn-sm" onclick="scrollToModuleView('${moduleTitle}')">
                    <span class="icon-no-wrap">
                        <i class="fas fa-cube"></i>${moduleTitle}
                    </span>
                    <span class="badge bg-light text-dark ms-1">${matchCount}</span>
                </button>
            `);
            moduleNavButtons.append(moduleBtn);
        });
    } else {
        $('#stream-results .result-file-view').each(function() {
            const fileTitle = $(this).find('h4').text().trim();
            const matchCount = $(this).find('.match-count').text();
            
            const fileBtn = $(`
                <button class="btn nav-btn nav-btn-file btn-sm" onclick="scrollToFileView('${fileTitle}')">
                    <span class="icon-no-wrap">
                        <i class="fas fa-file"></i>${fileTitle}
                    </span>
                    <span class="badge bg-light text-dark ms-1">${matchCount}</span>
                </button>
            `);
            moduleNavButtons.append(fileBtn);
        });
    }
    
    // 顯示快速導航
    if (moduleNavButtons.children().length > 0) {
        quickNav.show();
    }
}

function scrollToModuleView(moduleTitle) {
    const moduleElement = $('#stream-results .result-module').filter(function() {
        return $(this).find('h4').text().trim() === moduleTitle;
    });
    
    scrollToElement(moduleElement);
}

function scrollToFileView(fileTitle) {
    const fileElement = $('#stream-results .result-file-view').filter(function() {
        return $(this).find('h4').text().trim() === fileTitle;
    });
    
    scrollToElement(fileElement);
}

function scrollToElement(element) {
    if (element.length > 0) {
        $('html, body').animate({
            scrollTop: element.offset().top - 100
        }, 500);
        
        // 添加高亮效果
        element.addClass('animate__animated animate__pulse');
        setTimeout(() => {
            element.removeClass('animate__animated animate__pulse');
        }, 1000);
    }
}

// 其他輔助函數
function scrollToModule(moduleTitle) {
    scrollToModuleView(moduleTitle);
}

function scrollToTop() {
    $('html, body').animate({
        scrollTop: 0
    }, 500);
}

function toggleNavigation() {
    const quickNav = $('#quick-navigation');
    const navToggleBtn = $('#nav-toggle-btn');
    
    if (quickNav.is(':visible')) {
        quickNav.slideUp(300);
        navToggleBtn.html('<i class="fas fa-compass me-1"></i>顯示導航');
    } else {
        quickNav.slideDown(300);
        navToggleBtn.html('<i class="fas fa-times me-1"></i>隱藏導航');
    }
}

function animateNumber(selector, newValue) {
    const element = $(selector);
    const isNumeric = !isNaN(newValue) && newValue !== '';
    
    if (isNumeric) {
        const oldValue = parseInt(element.text()) || 0;
        const targetValue = parseInt(newValue);
        
        if (targetValue > oldValue) {
            element.addClass('number-pulse');
            
            $({ counter: oldValue }).animate({ counter: targetValue }, {
                duration: 800,
                easing: 'easeOutQuart',
                step: function() {
                    element.text(Math.ceil(this.counter));
                },
                complete: function() {
                    element.text(targetValue);
                    setTimeout(() => {
                        element.removeClass('number-pulse');
                    }, 500);
                }
            });
        }
    } else {
        element.text(newValue);
    }
}

function highlightKeyword(text, keyword) {
    if (!text || !keyword) return text;
    
    const escapedKeyword = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedKeyword})`, 'gi');
    
    return text.replace(regex, '<span class="keyword-highlight">$1</span>');
}

function playNotificationSound(type) {
    if (!audioContext) return;
    
    try {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        const soundMap = {
            'success': { freq: 800, duration: 0.2 },
            'start': { freq: 600, duration: 0.3 },
            'discovery': { freq: 900, duration: 0.15 },
            'match': { freq: 1000, duration: 0.1 },
            'complete': { freq: [800, 1000, 1200], duration: 0.5 }
        };
        
        const sound = soundMap[type] || soundMap['success'];
        
        if (Array.isArray(sound.freq)) {
            sound.freq.forEach((freq, index) => {
                setTimeout(() => {
                    const osc = audioContext.createOscillator();
                    const gain = audioContext.createGain();
                    
                    osc.connect(gain);
                    gain.connect(audioContext.destination);
                    
                    osc.frequency.value = freq;
                    osc.type = 'sine';
                    
                    gain.gain.setValueAtTime(0.1, audioContext.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
                    
                    osc.start(audioContext.currentTime);
                    osc.stop(audioContext.currentTime + 0.3);
                }, index * 0.1);
            });
        } else {
            oscillator.frequency.value = sound.freq;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + sound.duration);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + sound.duration);
        }
    } catch (e) {
        console.log('🔇 播放音效失敗:', e);
    }
}

function showAlert(message, type) {
    const alertContainer = $('#alert-container');
    const alert = $(`
        <div class="alert alert-${type} alert-dismissible fade show animate__animated animate__fadeInDown" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `);
    
    alertContainer.empty().append(alert);
    
    setTimeout(() => {
        alert.alert('close');
    }, 5000);
}

function exportResults() {
    showAlert('🔄 匯出功能開發中...', 'info');
}

function openSmartAnalysis(module, keyword, filePath) {
    console.log('🧠 開啟智能分析:', module, keyword, filePath);
    
    try {
        const analysisUrl = `/smart_analysis?module=${encodeURIComponent(module)}&keyword=${encodeURIComponent(keyword)}&file=${encodeURIComponent(filePath)}`;
        
        const analysisWindow = window.open(
            analysisUrl + '#loading', 
            `smart_analysis_${Date.now()}`,
            'width=1200,height=800,scrollbars=yes,resizable=yes,toolbar=no,menubar=no,location=no'
        );
        
        if (!analysisWindow) {
            showAlert('⚠️ 彈出視窗被阻止，將在當前頁面開啟智能分析', 'warning');
            setTimeout(() => {
                window.open(analysisUrl, '_blank');
            }, 1000);
        } else {
            showAlert('🧠 正在開啟 AI 智能分析...', 'info');
            playNotificationSound('discovery');
            
            setTimeout(() => {
                try {
                    analysisWindow.focus();
                } catch (e) {
                    console.log('無法聚焦到新視窗');
                }
            }, 500);
        }
        
    } catch (e) {
        console.error('❌ 開啟智能分析失敗:', e);
        showAlert('❌ 開啟智能分析失敗，請稍後再試', 'danger');
    }
}

function addCustomStyles() {
    if ($('#custom-enhanced-styles').length > 0) {
        return;
    }
    
    const styles = `
        <style id="custom-enhanced-styles">
        /* 檢視模式控制 */
        .view-controls {
            background: rgba(255,255,255,0.9);
            border-radius: 12px;
            padding: 1rem;
            border: 1px solid #dee2e6;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        /* 分析進度圖示 */
        .analysis-progress-icon {
            display: inline-block;
            animation: none;
        }
        
        .analysis-progress-icon .fa-spinner {
            animation: spin 1.5s linear infinite;
        }
        
        /* 檔案檢視樣式 */
        .result-file-view {
            background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%);
            color: #e65100;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            border-left: 5px solid #ff9800;
        }
        
        .result-module-in-file {
            background: rgba(255,255,255,0.4);
            border-radius: 12px;
            padding: 18px;
            margin-bottom: 15px;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            border: 1px solid rgba(255,255,255,0.3);
            border-left: 3px solid #ff9800;
        }
        
        /* 導航按鈕樣式 */
        .file-module-navigation,
        .module-file-navigation {
            background: rgba(255,255,255,0.3);
            border-radius: 12px;
            padding: 15px;
            border: 1px solid rgba(255,255,255,0.2);
            backdrop-filter: blur(5px);
            transition: all 0.3s ease;
        }
        
        .nav-btn-file {
            background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);
            color: white;
            border: none;
            font-size: 0.85rem;
            transition: all 0.3s ease;
            border-radius: 20px;
        }
        
        .nav-btn-file:hover {
            background: linear-gradient(135deg, #f57c00 0%, #ff9800 100%);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 152, 0, 0.3);
        }
        
        /* 拖曳區域優化 */
        .drag-over {
            background: rgba(102, 126, 234, 0.1) !important;
            border-color: #667eea !important;
            transform: scale(1.02);
        }
        
        /* 浮動按鈕置中 */
        .floating-btn {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        /* 圖示間距優化 */
        .icon-no-wrap {
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
        }
        
        .icon-no-wrap i {
            margin-right: 0.5rem;
            flex-shrink: 0;
        }
        
        /* 響應式優化 */
        @media (max-width: 768px) {
            .view-controls {
                text-align: center;
            }
            
            .view-controls .btn-group {
                width: 100%;
            }
            
            .view-controls .btn {
                flex: 1;
            }
        }
        
        /* 動畫優化 */
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .number-pulse {
            animation: numberPulse 0.6s ease-in-out;
        }
        
        @keyframes numberPulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); color: #ff6b6b; }
            100% { transform: scale(1); }
        }
        </style>
    `;
    
    $('head').append(styles);
    console.log('🎨 自定義樣式已載入');
}