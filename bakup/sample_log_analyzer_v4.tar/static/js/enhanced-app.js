// 全域變數
let currentPath = '/home/vince_lin/Rust_Project';
let selectedFiles = [];
let droppedFiles = [];  // 新增：拖曳檔案列表
let keywords = {};
let allSelectMode = false;
let currentAnalysisId = null;
let eventSource = null;
let audioContext = null;
let analysisModal = null;
let pageHistory = [];  // 新增：頁面歷史記錄

// 頁面載入時初始化
$(document).ready(function() {
    console.log('🚀 Enhanced Log 分析平台載入完成');
    
    // 儲存頁面狀態
    savePageState();
    
    // 載入樣式
    addCustomStyles();
    
    // 初始化應用
    initializeApp();
    
    // 設置事件監聽器
    setupEventListeners();
    
    // 設置拖曳功能
    setupDropAnalysis();
    
    // 載入目錄
    loadDirectory(currentPath);
    
    // 初始化模態框
    try {
        analysisModal = new bootstrap.Modal(document.getElementById('analysisModal'), {
            backdrop: 'static',
            keyboard: false
        });
        console.log('✅ 模態框初始化成功');
    } catch (e) {
        console.error('❌ 模態框初始化失敗:', e);
    }
    
    // 綁定模態框按鈕事件
    setupModalButtonEvents();
    
    // 添加鍵盤快捷鍵
    setupKeyboardShortcuts();
    
    console.log('✅ 初始化完成');
});

function savePageState() {
    const state = {
        url: window.location.href,
        timestamp: Date.now(),
        selectedFiles: selectedFiles,
        currentPath: currentPath,
        scrollPosition: window.scrollY
    };
    
    pageHistory.push(state);
    
    // 限制歷史記錄數量
    if (pageHistory.length > 10) {
        pageHistory.shift();
    }
    
    console.log('💾 頁面狀態已儲存');
}

function setupDropAnalysis() {
    console.log('🎯 設置拖曳分析功能');
    
    const dropZone = document.getElementById('drop-analysis-zone');
    const quickAnalysisFile = document.getElementById('quick-analysis-file');
    
    // 拖曳區域事件
    dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('drag-over');
    });
    
    dropZone.addEventListener('dragleave', function(e) {
        e.preventDefault();
        if (!dropZone.contains(e.relatedTarget)) {
            $(this).removeClass('drag-over');
        }
    });
    
    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        $(this).removeClass('drag-over');
        
        const files = Array.from(e.dataTransfer.files);
        handleDroppedFiles(files);
    });
    
    // 檔案選擇器事件
    quickAnalysisFile.addEventListener('change', function() {
        const files = Array.from(this.files);
        handleDroppedFiles(files);
    });
    
    // 選項變更事件
    $('#include-browser-files, #include-dropped-files').on('change', updateAnalysisCount);
    
    console.log('✅ 拖曳分析功能設置完成');
}

function handleDroppedFiles(files) {
    console.log('📁 處理拖曳檔案:', files.length, '個');
    
    const validExtensions = ['.log', '.txt', '.out', '.err'];
    const validFiles = files.filter(file => {
        const extension = '.' + file.name.split('.').pop().toLowerCase();
        return validExtensions.includes(extension);
    });
    
    if (validFiles.length === 0) {
        showAlert('⚠️ 請拖曳有效的日誌檔案 (.log, .txt, .out, .err)', 'warning');
        return;
    }
    
    // 添加到拖曳檔案列表
    validFiles.forEach(file => {
        // 檢查是否已存在
        const exists = droppedFiles.some(f => f.name === file.name && f.size === file.size);
        if (!exists) {
            droppedFiles.push({
                name: file.name,
                size: file.size,
                lastModified: file.lastModified,
                file: file
            });
        }
    });
    
    // 更新顯示
    updateDroppedFilesList();
    updateAnalysisCount();
    
    showAlert(`✅ 已添加 ${validFiles.length} 個檔案到快速分析列表`, 'success');
}

function updateDroppedFilesList() {
    const container = $('#dropped-files-container');
    const listElement = $('#dropped-files-list');
    
    if (droppedFiles.length === 0) {
        listElement.hide();
        return;
    }
    
    listElement.show();
    container.empty();
    
    droppedFiles.forEach((fileInfo, index) => {
        const fileElement = $(`
            <div class="dropped-file-item" data-index="${index}">
                <div class="d-flex align-items-center">
                    <div class="file-icon log-file me-3">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="mb-1">${fileInfo.name}</h6>
                        <small class="text-muted">
                            ${formatFileSize(fileInfo.size)} • 
                            ${new Date(fileInfo.lastModified).toLocaleString()}
                        </small>
                    </div>
                    <button class="btn btn-outline-danger btn-sm" onclick="removeDroppedFile(${index})">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `);
        
        container.append(fileElement);
    });
}

function removeDroppedFile(index) {
    droppedFiles.splice(index, 1);
    updateDroppedFilesList();
    updateAnalysisCount();
}

function clearDroppedFiles() {
    droppedFiles = [];
    updateDroppedFilesList();
    updateAnalysisCount();
    showAlert('🗑️ 已清空拖曳檔案列表', 'info');
}

function updateAnalysisCount() {
    const includeBrowser = $('#include-browser-files').is(':checked');
    const includeDropped = $('#include-dropped-files').is(':checked');
    
    const browserCount = includeBrowser ? selectedFiles.length : 0;
    const droppedCount = includeDropped ? droppedFiles.length : 0;
    const totalCount = browserCount + droppedCount;
    
    $('#browser-files-count').text(browserCount);
    $('#dropped-files-count').text(droppedCount);
    $('#total-files-count').text(totalCount);
    
    // 更新快速分析按鈕
    const quickAnalyzeBtn = $('#quick-analyze-btn');
    const hasKeywords = Object.keys(keywords).length > 0;
    const hasFiles = totalCount > 0;
    
    quickAnalyzeBtn.prop('disabled', !hasKeywords || !hasFiles);
    
    if (!hasKeywords) {
        quickAnalyzeBtn.html('<i class="fas fa-exclamation-triangle me-2"></i>請先上傳關鍵字');
    } else if (!hasFiles) {
        quickAnalyzeBtn.html('<i class="fas fa-folder-open me-2"></i>請選擇檔案');
    } else {
        quickAnalyzeBtn.html(`<i class="fas fa-rocket me-2"></i>分析 ${totalCount} 個檔案`);
    }
}

function startQuickAnalysis() {
    console.log('⚡ 開始快速分析');
    
    const includeBrowser = $('#include-browser-files').is(':checked');
    const includeDropped = $('#include-dropped-files').is(':checked');
    
    // 合併檔案列表
    let analysisFiles = [];
    
    if (includeBrowser) {
        analysisFiles = analysisFiles.concat(selectedFiles);
    }
    
    if (includeDropped) {
        // 對於拖曳的檔案，我們需要上傳到服務器
        showAlert('📤 正在上傳拖曳檔案...', 'info');
        uploadDroppedFilesAndAnalyze(analysisFiles);
        return;
    }
    
    if (analysisFiles.length === 0) {
        showAlert('⚠️ 請選擇要分析的檔案', 'warning');
        return;
    }
    
    // 使用現有檔案開始分析
    selectedFiles = analysisFiles;
    startStreamAnalysis();
}

function uploadDroppedFilesAndAnalyze(browserFiles) {
    // 這裡需要實現檔案上傳功能
    // 暫時顯示提示訊息
    showAlert('🚧 拖曳檔案上傳功能開發中，請使用瀏覽器選擇檔案', 'info');
    
    // 如果只有瀏覽器檔案，直接分析
    if (browserFiles.length > 0) {
        selectedFiles = browserFiles;
        startStreamAnalysis();
    }
}

function updateSelectedCount() {
    $('#selected-count').text(selectedFiles.length);
    const analyzeBtn = $('#analyze-btn');
    
    if (selectedFiles.length > 0 && Object.keys(keywords).length > 0) {
        analyzeBtn.prop('disabled', false);
    } else {
        analyzeBtn.prop('disabled', true);
    }
    
    // 同時更新快速分析計數
    updateAnalysisCount();
    
    console.log('📊 已選擇檔案數量:', selectedFiles.length);
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function setupModalButtonEvents() {
    // 停止分析按鈕
    $(document).off('click', '#stop-analysis-btn').on('click', '#stop-analysis-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('🛑 停止分析按鈕被點擊');
        stopStreamAnalysis();
    });
    
    // 關閉按鈕
    $(document).off('click', '#close-analysis-btn').on('click', '#close-analysis-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('🚪 關閉按鈕被點擊');
        
        if (currentAnalysisId) {
            if (confirm('分析正在進行中，確定要關閉嗎？這將停止分析。')) {
                stopStreamAnalysis();
            }
        } else {
            if (analysisModal) {
                analysisModal.hide();
            }
        }
    });
    
    // 模態框的X按鈕
    $(document).off('click', '#analysisModal .btn-close').on('click', '#analysisModal .btn-close', function(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('❌ 模態框X按鈕被點擊');
        
        if (currentAnalysisId) {
            if (confirm('分析正在進行中，確定要關閉嗎？這將停止分析。')) {
                stopStreamAnalysis();
            }
        } else {
            if (analysisModal) {
                analysisModal.hide();
            }
        }
    });
    
    console.log('✅ 模態框按鈕事件已綁定');
}

function initializeApp() {
    console.log('🔧 初始化應用...');
    
    // 初始化音頻上下文
    try {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
        console.log('⚠️ 音頻上下文初始化失敗，音效將不可用');
    }
    
    // 載入已有的關鍵字
    $.get('/api/keywords')
        .done(function(data) {
            console.log('📋 載入關鍵字:', data);
            if (Object.keys(data).length > 0) {
                keywords = data;
                updateKeywordPreview();
            }
        })
        .fail(function() {
            console.log('❌ 載入關鍵字失敗');
        });
}

function setupEventListeners() {
    console.log('🎛️ 設置事件監聽器...');
    
    // 檔案上傳
    $('#keyword-file').on('change', function() {
        const file = this.files[0];
        if (file) {
            console.log('📁 選擇檔案:', file.name);
            uploadKeywords(file);
        }
    });
    
    // 拖拽上傳
    const uploadZone = document.getElementById('upload-zone');
    if (uploadZone) {
        uploadZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            $(this).addClass('dragover');
        });
        
        uploadZone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            $(this).removeClass('dragover');
        });
        
        uploadZone.addEventListener('drop', function(e) {
            e.preventDefault();
            $(this).removeClass('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                uploadKeywords(files[0]);
            }
        });
    }
    
    // 路徑輸入框 Enter 鍵
    $('#path-input').on('keypress', function(e) {
        if (e.which === 13) {
            navigateToPath();
        }
    });
    
    console.log('✅ 事件監聽器設置完成');
}

function setupKeyboardShortcuts() {
    // Ctrl + Enter 開始分析
    $(document).keydown(function(e) {
        if (e.ctrlKey && e.which === 13) {
            e.preventDefault();
            if (!$('#analyze-btn').prop('disabled')) {
                startStreamAnalysis();
            }
        }
        
        // Esc 停止分析
        if (e.which === 27 && currentAnalysisId) {
            e.preventDefault();
            if (confirm('確定要停止分析嗎？')) {
                stopStreamAnalysis();
            }
        }
        
        // Ctrl + N 切換導航
        if (e.ctrlKey && e.which === 78) {
            e.preventDefault();
            toggleNavigation();
        }
    });
}

function uploadKeywords(file) {
    if (!file) {
        console.log('❌ 沒有選擇檔案');
        return;
    }
    
    console.log('📤 上傳關鍵字檔案:', file.name);
    
    const formData = new FormData();
    formData.append('file', file);
    
    showAlert('📤 上傳中...', 'info');
    
    $.ajax({
        url: '/api/upload_keywords',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            console.log('📋 上傳回應:', response);
            if (response.success) {
                keywords = response.keywords;
                updateKeywordPreview();
                showAlert(`✅ ${response.message}`, 'success');
                playNotificationSound('success');
            } else {
                showAlert(`❌ ${response.message}`, 'danger');
            }
        },
        error: function(xhr, status, error) {
            console.error('❌ 上傳失敗:', status, error);
            showAlert('❌ 上傳失敗', 'danger');
        }
    });
}

function updateKeywordPreview() {
    const preview = $('#keyword-preview');
    const modules = $('#keyword-modules');
    
    if (Object.keys(keywords).length === 0) {
        preview.hide();
        return;
    }
    
    modules.empty();
    for (const [module, keywordList] of Object.entries(keywords)) {
        const moduleElement = $(`
            <div class="keyword-module animate__animated animate__fadeIn">
                <strong>${module}:</strong> ${keywordList.join(', ')}
            </div>
        `);
        modules.append(moduleElement);
    }
    
    preview.show();
    console.log('📋 關鍵字預覽已更新');
}

function loadDirectory(path) {
    console.log('📂 載入目錄:', path);
    
    $('#file-list').html(`
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">載入中...</span>
            </div>
            <p class="mt-3 text-muted">載入檔案列表中...</p>
        </div>
    `);
    
    $.get('/api/browse', { path: path })
        .done(function(response) {
            console.log('📂 目錄載入回應:', response);
            
            if (response.error) {
                $('#file-list').html(`
                    <div class="text-center py-5">
                        <i class="fas fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                        <p class="text-muted">${response.error}</p>
                        <button class="btn btn-primary" onclick="loadDirectory('${currentPath}')">重試</button>
                    </div>
                `);
                return;
            }
            
            currentPath = response.current_path;
            $('#path-input').val(currentPath);
            updateBreadcrumb();
            renderFileList(response.items);
        })
        .fail(function(xhr, status, error) {
            console.error('❌ 載入目錄失敗:', status, error);
            $('#file-list').html(`
                <div class="text-center py-5">
                    <i class="fas fa-wifi fa-3x text-danger mb-3"></i>
                    <p class="text-muted">載入失敗，請檢查網路連接</p>
                    <button class="btn btn-primary" onclick="loadDirectory('${currentPath}')">重試</button>
                </div>
            `);
        });
}

function renderFileList(items) {
    console.log('📋 渲染檔案列表:', items.length, '個項目');
    
    const fileList = $('#file-list');
    fileList.empty();
    
    if (items.length === 0) {
        fileList.html(`
            <div class="text-center py-5">
                <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                <p class="text-muted">此目錄為空</p>
            </div>
        `);
        return;
    }
    
    items.forEach(function(item, index) {
        const isSelected = selectedFiles.includes(item.path);
        
        const fileItem = $(`
            <div class="file-item ${isSelected ? 'selected' : ''}" data-path="${item.path}" data-type="${item.type}">
                <div class="d-flex align-items-center">
                    ${item.type === 'file' && !item.is_parent ? 
                        `<input type="checkbox" class="form-check-input me-3" ${isSelected ? 'checked' : ''}>` : 
                        '<div class="me-3" style="width: 16px;"></div>'
                    }
                    <div class="file-icon ${item.is_parent ? 'parent' : item.type === 'directory' ? 'directory' : 'log-file'}">
                        <i class="fas ${item.is_parent ? 'fa-arrow-left' : item.type === 'directory' ? 'fa-folder' : 'fa-file-alt'}"></i>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="mb-1">${item.name}</h6>
                        <small class="text-muted">
                            ${item.size ? item.size + ' • ' : ''}${item.modified}
                        </small>
                    </div>
                </div>
            </div>
        `);
        
        // 點擊事件
        fileItem.on('click', function(e) {
            console.log('👆 點擊項目:', item.name, item.type);
            
            if (item.type === 'directory') {
                loadDirectory(item.path);
            } else if (item.type === 'file' && !item.is_parent) {
                if (e.target.type !== 'checkbox') {
                    const checkbox = $(this).find('input[type="checkbox"]');
                    checkbox.prop('checked', !checkbox.prop('checked'));
                    checkbox.trigger('change');
                }
            }
        });
        
        // 檔案選擇事件
        const checkbox = fileItem.find('input[type="checkbox"]');
        checkbox.on('change', function(e) {
            e.stopPropagation();
            
            const path = item.path;
            const isChecked = $(this).is(':checked');
            
            console.log('☑️ 檔案選擇狀態改變:', path, isChecked);
            
            if (isChecked) {
                if (!selectedFiles.includes(path)) {
                    selectedFiles.push(path);
                }
                fileItem.addClass('selected');
            } else {
                selectedFiles = selectedFiles.filter(f => f !== path);
                fileItem.removeClass('selected');
            }
            
            updateSelectedCount();
        });
        
        fileList.append(fileItem);
    });
    
    console.log('✅ 檔案列表渲染完成');
}

function updateBreadcrumb() {
    const breadcrumb = $('#breadcrumb');
    const pathParts = currentPath.split('/').filter(part => part);
    
    breadcrumb.empty();
    
    // 根目錄
    const rootItem = $(`<li class="breadcrumb-item"><a href="#" onclick="loadDirectory('/')">根目錄</a></li>`);
    breadcrumb.append(rootItem);
    
    // 路徑部分
    let buildPath = '';
    pathParts.forEach((part, index) => {
        buildPath += '/' + part;
        const isLast = index === pathParts.length - 1;
        
        if (isLast) {
            breadcrumb.append(`<li class="breadcrumb-item active">${part}</li>`);
        } else {
            const pathToNavigate = buildPath;
            breadcrumb.append(`<li class="breadcrumb-item"><a href="#" onclick="loadDirectory('${pathToNavigate}')">${part}</a></li>`);
        }
    });
    
    console.log('🧭 面包屑導航已更新:', currentPath);
}

function navigateToPath() {
    const path = $('#path-input').val().trim();
    if (path) {
        console.log('🎯 導航到路徑:', path);
        loadDirectory(path);
    }
}

function refreshBrowser() {
    console.log('🔄 刷新瀏覽器');
    loadDirectory(currentPath);
}

function toggleSelectAll() {
    allSelectMode = !allSelectMode;
    console.log('🔄 切換全選模式:', allSelectMode);
    
    $('.file-item[data-type="file"]').each(function() {
        const checkbox = $(this).find('input[type="checkbox"]');
        const path = $(this).data('path');
        
        if (allSelectMode) {
            checkbox.prop('checked', true);
            $(this).addClass('selected');
            if (!selectedFiles.includes(path)) {
                selectedFiles.push(path);
            }
        } else {
            checkbox.prop('checked', false);
            $(this).removeClass('selected');
            selectedFiles = selectedFiles.filter(f => f !== path);
        }
    });
    
    updateSelectedCount();
    
    // 更新按鈕文字
    const btn = $('button[onclick="toggleSelectAll()"]');
    if (allSelectMode) {
        btn.html('<i class="fas fa-times me-1"></i>取消全選');
    } else {
        btn.html('<i class="fas fa-check-square me-1"></i>全選');
    }
}

function updateSelectedCount() {
    $('#selected-count').text(selectedFiles.length);
    const analyzeBtn = $('#analyze-btn');
    
    if (selectedFiles.length > 0 && Object.keys(keywords).length > 0) {
        analyzeBtn.prop('disabled', false);
    } else {
        analyzeBtn.prop('disabled', true);
    }
    
    console.log('📊 已選擇檔案數量:', selectedFiles.length);
}

function startStreamAnalysis() {
    console.log('🚀 開始流式分析');
    
    if (selectedFiles.length === 0) {
        showAlert('⚠️ 請選擇要分析的檔案', 'warning');
        return;
    }
    
    if (Object.keys(keywords).length === 0) {
        showAlert('⚠️ 請先上傳關鍵字清單', 'warning');
        return;
    }
    
    // 直接開始分析，不顯示模態框，讓用戶可以繼續操作
    initializeStreamingAnalysis();
    
    // 啟動流式分析
    $.ajax({
        url: '/api/analyze_stream',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            files: selectedFiles
        }),
        success: function(response) {
            console.log('🎯 流式分析啟動:', response);
            if (response.success) {
                currentAnalysisId = response.analysis_id;
                startEventSource(response.analysis_id);
                showAlert('🚀 分析已開始，結果將即時顯示在下方！', 'success');
                playNotificationSound('start');
                
                // 更新分析按鈕狀態
                updateAnalysisButtonState('running');
            } else {
                showAlert(`❌ ${response.message}`, 'danger');
                updateAnalysisButtonState('idle');
            }
        },
        error: function(xhr, status, error) {
            console.error('❌ 啟動分析失敗:', status, error);
            showAlert('❌ 啟動分析失敗，請檢查網路連接', 'danger');
            updateAnalysisButtonState('idle');
        }
    });
}

function initializeStreamingAnalysis() {
    const resultsContainer = $('#analysis-results');
    const statsContainer = $('#result-stats');
    const detailsContainer = $('#detailed-results');
    
    // 顯示分析區域
    resultsContainer.show();
    
    // 初始化統計區域，包含停止按鈕
    statsContainer.html(`
        <div class="col-md-2">
            <div class="card bg-primary text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-file-alt"></i>檔案</h5>
                    <h2 id="stat-files" class="counter-number">${selectedFiles.length}</h2>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card bg-success text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-cube"></i>模組</h5>
                    <h2 id="stat-modules" class="counter-number">0/${Object.keys(keywords).length}</h2>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card bg-info text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-search"></i>匹配</h5>
                    <h2 id="stat-matches" class="counter-number">0</h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-cogs"></i>進度</h5>
                    <div class="progress progress-modern mb-2">
                        <div class="progress-bar progress-bar-animated" id="progress-bar" style="width: 0%"></div>
                    </div>
                    <small id="progress-text" class="progress-text">準備中...</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-secondary text-white stats-card">
                <div class="card-body text-center">
                    <h5 class="icon-no-wrap"><i class="fas fa-clock"></i>狀態</h5>
                    <div id="analysis-status-display">
                        <div class="d-flex align-items-center justify-content-center">
                            <div class="spinner-border spinner-border-sm me-2" role="status" id="status-spinner"></div>
                            <span id="current-module-display">初始化中...</span>
                        </div>
                        <button class="btn btn-danger btn-sm mt-2" id="stop-analysis-inline" onclick="stopStreamAnalysis()">
                            <i class="fas fa-stop me-1"></i>停止分析
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    // 初始化結果區域
    detailsContainer.html(`
        <div id="stream-results" class="stream-results">
            <div class="analysis-starting animate__animated animate__fadeIn">
                <div class="text-center py-4">
                    <div class="d-flex align-items-center justify-content-center mb-3">
                        <div class="spinner-border text-primary me-3" role="status"></div>
                        <h5 class="mb-0">正在啟動分析引擎...</h5>
                    </div>
                    <p class="text-muted">結果將在下方即時顯示，您可以繼續操作其他功能</p>
                </div>
            </div>
        </div>
    `);
    
    // 滾動到結果區域
    $('html, body').animate({
        scrollTop: resultsContainer.offset().top - 50
    }, 300);
}

function updateAnalysisButtonState(state) {
    const analyzeBtn = $('#analyze-btn');
    
    switch (state) {
        case 'running':
            analyzeBtn.html('<i class="fas fa-spinner fa-spin me-2"></i>分析進行中')
                      .removeClass('btn-danger-gradient')
                      .addClass('btn-warning')
                      .prop('disabled', false)
                      .attr('onclick', 'stopStreamAnalysis()');
            break;
        case 'stopping':
            analyzeBtn.html('<i class="fas fa-circle-notch fa-spin me-2"></i>正在停止')
                      .addClass('btn-secondary')
                      .prop('disabled', true);
            break;
        case 'idle':
        default:
            analyzeBtn.html('<i class="fas fa-stream me-2"></i>開始流式分析')
                      .removeClass('btn-warning btn-secondary')
                      .addClass('btn-danger-gradient')
                      .prop('disabled', selectedFiles.length === 0 || Object.keys(keywords).length === 0)
                      .attr('onclick', 'startStreamAnalysis()');
            break;
    }
}

function updateProgressStatus(moduleText, fileText) {
    $('#current-module-display').html(`
        <div class="small">${moduleText}</div>
        <div class="text-muted" style="font-size: 0.75rem;">${fileText}</div>
    `);
    $('#progress-text').text('分析中...');
}

function initializeAnalysisProgress() {
    const progressContent = $('#analysis-progress-content');
    
    progressContent.html(`
        <div class="analysis-progress">
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card bg-primary text-white">
                        <div class="card-body text-center">
                            <h5><i class="fas fa-file-alt me-2"></i>分析檔案</h5>
                            <h2 id="progress-files">${selectedFiles.length}</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-info text-white">
                        <div class="card-body text-center">
                            <h5><i class="fas fa-cube me-2"></i>監控模組</h5>
                            <h2 id="progress-modules">${Object.keys(keywords).length}</h2>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span><i class="fas fa-tasks me-2"></i>整體進度</span>
                    <span id="progress-percentage">0%</span>
                </div>
                <div class="progress progress-modern">
                    <div class="progress-bar progress-bar-animated" id="main-progress-bar" style="width: 0%"></div>
                </div>
            </div>
            
            <div class="current-status">
                <h6><i class="fas fa-info-circle me-2"></i>當前狀態</h6>
                <div class="alert alert-info">
                    <div class="d-flex align-items-center">
                        <div class="spinner-border spinner-border-sm me-3" role="status"></div>
                        <div class="flex-grow-1">
                            <div id="current-module">正在準備分析...</div>
                            <small class="text-muted" id="current-file">初始化中</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="live-matches" class="live-matches">
                <h6><i class="fas fa-search me-2"></i>即時發現</h6>
                <div id="match-stream" class="match-stream">
                    <p class="text-muted">等待匹配結果...</p>
                </div>
            </div>
        </div>
    `);
    
    // 初始化結果顯示區域
    initializeResultsDisplay();
}

function initializeResultsDisplay() {
    const resultsContainer = $('#analysis-results');
    const statsContainer = $('#result-stats');
    const detailsContainer = $('#detailed-results');
    
    // 顯示分析區域
    resultsContainer.show();
    
    // 初始化統計區域
    statsContainer.html(`
        <div class="col-md-3">
            <div class="card bg-primary text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-file-alt"></i>分析檔案</h5>
                    <h2 id="stat-files" class="counter-number">${selectedFiles.length}</h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-cube"></i>完成模組</h5>
                    <h2 id="stat-modules" class="counter-number">0/${Object.keys(keywords).length}</h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-search"></i>找到匹配</h5>
                    <h2 id="stat-matches" class="counter-number">0</h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white stats-card">
                <div class="card-body">
                    <h5 class="icon-no-wrap"><i class="fas fa-clock"></i>耗時</h5>
                    <h2 id="stat-time" class="counter-number">0s</h2>
                </div>
            </div>
        </div>
    `);
    
    // 清空詳細結果
    detailsContainer.html(`
        <div id="stream-results" class="stream-results">
            <div class="text-center py-4">
                <div class="spinner-border text-primary mb-3" role="status"></div>
                <p class="text-muted">等待分析結果...</p>
            </div>
        </div>
    `);
    
    // 滾動到結果區域
    $('html, body').animate({
        scrollTop: resultsContainer.offset().top - 100
    }, 500);
}

function startEventSource(analysisId) {
    console.log('🌊 啟動 EventSource:', analysisId);
    
    // 關閉現有連接
    if (eventSource) {
        eventSource.close();
        eventSource = null;
    }
    
    try {
        // 建立新的 SSE 連接
        eventSource = new EventSource(`/api/analysis_stream/${analysisId}`);
        
        eventSource.onmessage = function(event) {
            try {
                const data = JSON.parse(event.data);
                // 使用 setTimeout 確保不阻塞 UI
                setTimeout(() => {
                    handleStreamMessage(data);
                }, 0);
            } catch (e) {
                console.error('❌ 解析 SSE 訊息失敗:', e, event.data);
            }
        };
        
        eventSource.onerror = function(event) {
            console.error('❌ EventSource 錯誤:', event);
            console.log('EventSource readyState:', eventSource?.readyState);
            
            // 如果連接關閉，清理資源
            if (!eventSource || eventSource.readyState === EventSource.CLOSED) {
                console.log('🔌 EventSource 連接已關閉');
                eventSource = null;
                // 不要自動調用 onAnalysisComplete，讓其他事件處理
            }
        };
        
        eventSource.onopen = function(event) {
            console.log('✅ EventSource 連接已建立');
        };
        
    } catch (e) {
        console.error('❌ 建立 EventSource 失敗:', e);
        showAlert('❌ 建立即時連接失敗', 'danger');
        analysisModal.hide();
    }
}

function handleStreamMessage(data) {
    try {
        console.log('📩 收到流式訊息:', data.type);
        
        switch (data.type) {
            case 'heartbeat':
                // 心跳訊息，保持連接
                break;
                
            case 'start':
                requestAnimationFrame(() => {
                    updateProgressStatus('🚀 分析開始', '正在初始化...');
                });
                break;
                
            case 'module_start':
                requestAnimationFrame(() => {
                    updateProgressStatus(`🔍 分析模組: ${data.module}`, '準備搜尋關鍵字...');
                });
                break;
                
            case 'file_start':
                requestAnimationFrame(() => {
                    updateProgressStatus(`📂 分析檔案: ${data.module}`, `正在處理: ${data.file.split('/').pop()}`);
                });
                break;
                
            case 'matches_found':
                // 使用 requestAnimationFrame 確保不阻塞UI
                requestAnimationFrame(() => {
                    handleMatchesFound(data);
                });
                break;
                
            case 'progress':
                requestAnimationFrame(() => {
                    updateProgress(data.progress);
                });
                break;
                
            case 'module_complete':
                requestAnimationFrame(() => {
                    updateModuleComplete(data);
                });
                break;
                
            case 'complete':
                requestAnimationFrame(() => {
                    handleAnalysisComplete(data);
                });
                break;
                
            case 'error':
            case 'timeout':
                requestAnimationFrame(() => {
                    handleAnalysisError(data);
                });
                break;
                
            default:
                console.log('🤔 未知訊息類型:', data.type);
        }
    } catch (e) {
        console.error('❌ 處理流式訊息時發生錯誤:', e, data);
    }
}

function updateProgressStatus(moduleText, fileText) {
    $('#current-module').text(moduleText);
    $('#current-file').text(fileText);
}

function updateProgress(progress) {
    $('#main-progress-bar').css('width', progress + '%');
    $('#progress-percentage').text(progress + '%');
}

function handleMatchesFound(data) {
    try {
        console.log('🎯 發現匹配 - 模組:', data.module, '檔案:', data.file.split('/').pop(), '匹配數:', data.matches.length);
        
        // 使用更強的節流機制避免UI卡頓
        if (window.matchesFoundTimeout) {
            clearTimeout(window.matchesFoundTimeout);
        }
        
        // 批量處理匹配數據，避免頻繁更新DOM
        if (!window.pendingMatches) {
            window.pendingMatches = [];
        }
        window.pendingMatches.push(data);
        
        // 延遲批量處理，合併多個匹配更新
        window.matchesFoundTimeout = setTimeout(() => {
            processPendingMatches();
            window.pendingMatches = [];
        }, 200); // 200ms的延遲批量處理
        
    } catch (e) {
        console.error('❌ 處理匹配結果時發生錯誤:', e, data);
    }
}

function processPendingMatches() {
    try {
        if (!window.pendingMatches || window.pendingMatches.length === 0) return;
        
        console.log('📦 批量處理', window.pendingMatches.length, '個匹配結果');
        
        // 合併相同模組和檔案的匹配
        const groupedMatches = {};
        
        window.pendingMatches.forEach(data => {
            const key = `${data.module}|${data.file}`;
            if (!groupedMatches[key]) {
                groupedMatches[key] = {
                    module: data.module,
                    file: data.file,
                    matches: [],
                    total_matches: data.total_matches
                };
            }
            groupedMatches[key].matches.push(...data.matches);
            groupedMatches[key].total_matches = data.total_matches; // 使用最新的總數
        });
        
        // 分批處理，避免一次處理太多
        const entries = Object.values(groupedMatches);
        const batchSize = 3; // 每批處理3個
        
        processBatch(entries, 0, batchSize);
        
    } catch (e) {
        console.error('❌ 批量處理匹配結果失敗:', e);
    }
}

function processBatch(entries, startIndex, batchSize) {
    if (startIndex >= entries.length) return;
    
    // 處理當前批次
    const endIndex = Math.min(startIndex + batchSize, entries.length);
    const batch = entries.slice(startIndex, endIndex);
    
    // 使用 requestIdleCallback 或 setTimeout 進行異步處理
    const processFunction = () => {
        batch.forEach(data => {
            try {
                // 更新統計 - 輕量級操作
                updateStatsLightweight(data.total_matches);
                
                // 限制即時匹配流的更新頻率
                if (Math.random() < 0.3) { // 只有30%的機率更新匹配流
                    addToMatchStreamLightweight(data);
                }
                
                // 更新結果顯示
                updateStreamResultsLightweight(data);
                
            } catch (e) {
                console.error('❌ 處理批次項目失敗:', e);
            }
        });
        
        // 處理下一批次，添加延遲避免阻塞
        if (endIndex < entries.length) {
            setTimeout(() => {
                processBatch(entries, endIndex, batchSize);
            }, 50); // 50ms延遲
        }
    };
    
    // 使用 requestIdleCallback 優先處理，回退到 setTimeout
    if (window.requestIdleCallback) {
        requestIdleCallback(processFunction, { timeout: 100 });
    } else {
        setTimeout(processFunction, 0);
    }
}

function updateStatsLightweight(totalMatches) {
    // 輕量級統計更新，減少DOM操作
    const statsElement = $('#stat-matches');
    if (statsElement.length > 0) {
        const currentValue = parseInt(statsElement.text()) || 0;
        if (totalMatches > currentValue) {
            statsElement.text(totalMatches);
        }
    }
}

function addToMatchStreamLightweight(data) {
    try {
        const matchStream = $('#match-stream');
        if (!matchStream.length) return;
        
        // 只顯示前2個匹配項目，減少DOM負載
        const matchesToShow = data.matches.slice(0, 2);
        
        matchesToShow.forEach(match => {
            const matchElement = $(`
                <div class="match-item">
                    <small class="text-muted">
                        ${data.module} • ${data.file.split('/').pop()} • 第 ${match.line_number} 行
                    </small>
                    <div class="match-content">${highlightKeyword(match.content, match.keyword)}</div>
                </div>
            `);
            
            matchStream.prepend(matchElement);
        });
        
        // 嚴格限制顯示數量
        const items = matchStream.find('.match-item');
        if (items.length > 10) {
            items.slice(10).remove();
        }
        
    } catch (e) {
        console.error('❌ 輕量級匹配流更新失敗:', e);
    }
}

function updateStreamResultsLightweight(data) {
    try {
        const streamResults = $('#stream-results');
        const moduleId = data.module.replace(/\s+/g, '-');
        
        // 檢查模組是否存在
        let moduleElement = $(`#stream-module-${moduleId}`);
        if (moduleElement.length === 0) {
            moduleElement = createStreamModuleElement(data.module, moduleId);
            streamResults.append(moduleElement);
        }
        
        // 輕量級更新模組內容
        updateStreamModuleContentLightweight(moduleElement, data);
        
    } catch (e) {
        console.error('❌ 輕量級結果更新失敗:', e);
    }
}

function updateStreamModuleContentLightweight(moduleElement, data) {
    try {
        const moduleId = data.module.replace(/\s+/g, '-');
        const filesContainer = $(`#module-files-${moduleId}`);
        
        // 更新匹配數量
        const matchCount = moduleElement.find('.match-count');
        matchCount.text(data.total_matches);
        
        // 檢查檔案是否存在
        const fileId = data.file.replace(/[^\w]/g, '-');
        let fileElement = filesContainer.find(`#file-${moduleId}-${fileId}`);
        
        if (fileElement.length === 0) {
            fileElement = createStreamFileElement(data, moduleId, fileId);
            filesContainer.append(fileElement);
            
            // 更新模組檔案導航 - 延遲執行
            setTimeout(() => {
                updateModuleFileNavigation(moduleId, data.file, data.module);
            }, 100);
        }
        
        // 簡化的檔案內容更新
        updateStreamFileContentLightweight(fileElement, data);
        
    } catch (e) {
        console.error('❌ 輕量級模組內容更新失敗:', e);
    }
}

function updateStreamFileContentLightweight(fileElement, data) {
    try {
        const moduleId = data.module.replace(/\s+/g, '-');
        const fileId = data.file.replace(/[^\w]/g, '-');
        
        // 更新檔案匹配計數
        const fileMatchCount = fileElement.find('.file-match-count');
        const currentTotal = parseInt(fileMatchCount.text().match(/\d+/)?.[0] || 0) + data.matches.length;
        fileMatchCount.text(`${currentTotal} 條匹配`);
        
        // 簡化的關鍵字組處理
        const keywordGroupsContainer = fileElement.find(`#keyword-groups-${moduleId}-${fileId}`);
        const keywordId = data.keyword.replace(/\s+/g, '-');
        let keywordGroup = keywordGroupsContainer.find(`#keyword-group-${moduleId}-${fileId}-${keywordId}`);
        
        if (keywordGroup.length === 0) {
            keywordGroup = createKeywordGroup(data, moduleId, fileId, keywordId);
            keywordGroupsContainer.append(keywordGroup);
        }
        
        // 批量添加匹配行
        const keywordContent = keywordGroup.find('.keyword-content');
        const fragment = document.createDocumentFragment();
        
        data.matches.forEach(match => {
            const lineElement = createMatchLineElement(match, data.file)[0];
            fragment.appendChild(lineElement);
        });
        
        keywordContent[0].appendChild(fragment);
        
        // 更新計數
        const existingCount = keywordContent.find('.result-line').length;
        keywordGroup.find('.keyword-count').text(`${existingCount} 條`);
        
    } catch (e) {
        console.error('❌ 輕量級檔案內容更新失敗:', e);
    }
}

function addToMatchStream(data) {
    try {
        const matchStream = $('#match-stream');
        
        if (!matchStream.length) {
            console.warn('⚠️ 匹配流容器不存在');
            return;
        }
        
        // 移除等待訊息
        matchStream.find('.text-muted').remove();
        
        // 批量處理匹配項目，避免逐個添加造成性能問題
        const fragment = document.createDocumentFragment();
        
        // 限制添加的匹配數量，避免UI過載
        const matchesToAdd = data.matches.slice(0, 5); // 只顯示前5個匹配
        
        matchesToAdd.forEach(match => {
            const matchElement = $(`
                <div class="match-item animate__animated animate__fadeInUp">
                    <small class="text-muted">
                        <i class="fas fa-cube me-1"></i>${data.module} • 
                        <i class="fas fa-file me-1"></i>${data.file.split('/').pop()} • 
                        <i class="fas fa-map-marker-alt me-1"></i>第 ${match.line_number} 行
                    </small>
                    <div class="match-content">${highlightKeyword(match.content, match.keyword)}</div>
                </div>
            `)[0];
            
            fragment.appendChild(matchElement);
        });
        
        // 一次性添加所有元素
        matchStream.prepend(fragment);
        
        // 限制顯示數量，移除過多的項目
        const items = matchStream.find('.match-item');
        if (items.length > 15) {
            items.slice(15).remove();
        }
        
        // 如果有更多匹配沒顯示，添加提示
        if (data.matches.length > matchesToAdd.length) {
            const moreInfo = $(`
                <div class="match-more-info text-muted small">
                    ...還有 ${data.matches.length - matchesToAdd.length} 個匹配項目
                </div>
            `);
            matchStream.find('.match-item').first().after(moreInfo);
        }
        
    } catch (e) {
        console.error('❌ 添加匹配流失敗:', e);
    }
}

function updateStreamResults(data) {
    const streamResults = $('#stream-results');
    const moduleId = data.module.replace(/\s+/g, '-');
    
    // 移除載入訊息
    streamResults.find('.text-center').remove();
    
    // 查找或創建模組元素
    let moduleElement = $(`#stream-module-${moduleId}`);
    if (moduleElement.length === 0) {
        moduleElement = createStreamModuleElement(data.module, moduleId);
        streamResults.append(moduleElement);
    }
    
    // 更新模組內容
    updateStreamModuleContent(moduleElement, data);
}

function createStreamModuleElement(module, moduleId) {
    const moduleElement = $(`
        <div class="result-module animate__animated animate__fadeInLeft" id="stream-module-${moduleId}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <h4 class="icon-no-wrap"><i class="fas fa-cube"></i>${module}</h4>
                    <p class="mb-3" id="module-info-${moduleId}">
                        <span class="icon-no-wrap">
                            <i class="fas fa-search"></i>找到 <span class="match-count">0</span> 次匹配
                        </span>
                        <span class="ms-3 analysis-status-text">
                            <span class="icon-no-wrap">
                                <i class="fas fa-clock"></i>分析中...
                            </span>
                        </span>
                    </p>
                </div>
                <div class="module-controls">
                    <button class="btn btn-back-to-top btn-sm" onclick="scrollToTop()" title="回到頂部">
                        <span class="icon-no-wrap">
                            <i class="fas fa-arrow-up"></i>頂部
                        </span>
                    </button>
                </div>
            </div>
            
            <!-- 模組檔案導航 -->
            <div class="module-file-navigation mb-3" id="module-file-nav-${moduleId}" style="display: none;">
                <div class="file-nav-header">
                    <h6 class="icon-no-wrap">
                        <i class="fas fa-folder-open"></i>包含檔案
                        <span class="badge bg-secondary ms-2" id="file-count-${moduleId}">0</span>
                    </h6>
                </div>
                <div class="file-nav-buttons" id="file-nav-buttons-${moduleId}">
                    <!-- 檔案導航按鈕將在這裡動態添加 -->
                </div>
            </div>
            
            <div id="module-files-${moduleId}" class="module-files">
                <!-- 檔案結果將在這裡顯示 -->
            </div>
        </div>
    `);
    
    return moduleElement;
}

function updateStreamModuleContent(moduleElement, data) {
    const moduleId = data.module.replace(/\s+/g, '-');
    const filesContainer = $(`#module-files-${moduleId}`);
    
    // 更新匹配數量
    const matchCount = moduleElement.find('.match-count');
    const oldCount = parseInt(matchCount.text()) || 0;
    const newCount = data.total_matches;
    
    if (newCount > oldCount) {
        animateNumber(matchCount, newCount);
    }
    
    // 查找或創建檔案元素
    const fileId = data.file.replace(/[^\w]/g, '-');
    let fileElement = filesContainer.find(`#file-${moduleId}-${fileId}`);
    
    if (fileElement.length === 0) {
        fileElement = createStreamFileElement(data, moduleId, fileId);
        filesContainer.append(fileElement);
        
        // 更新模組的檔案導航
        updateModuleFileNavigation(moduleId, data.file, data.module);
    }
    
    // 添加新的匹配到檔案中
    updateStreamFileContent(fileElement, data);
}

function updateModuleFileNavigation(moduleId, filePath, moduleName) {
    const fileNavContainer = $(`#module-file-nav-${moduleId}`);
    const fileNavButtons = $(`#file-nav-buttons-${moduleId}`);
    const fileCountBadge = $(`#file-count-${moduleId}`);
    
    const fileName = filePath.split('/').pop();
    const fileButtonId = `file-btn-${moduleId}-${fileName.replace(/[^\w]/g, '-')}`;
    
    // 檢查是否已經存在該檔案的按鈕
    if ($(`#${fileButtonId}`).length === 0) {
        // 創建檔案導航按鈕
        const fileButton = $(`
            <button class="btn nav-btn nav-btn-file btn-sm me-2 mb-2" 
                    id="${fileButtonId}"
                    onclick="scrollToFileInModule('${moduleId}', '${fileName}')" 
                    title="跳轉到 ${fileName}">
                <span class="icon-no-wrap">
                    <i class="fas fa-file"></i>${fileName}
                </span>
                <span class="badge bg-light text-dark ms-1 file-match-badge" id="badge-${fileButtonId}">0</span>
            </button>
        `);
        
        fileNavButtons.append(fileButton);
        
        // 顯示檔案導航區域
        fileNavContainer.show();
        
        // 更新檔案數量
        const currentFileCount = fileNavButtons.find('.nav-btn').length;
        fileCountBadge.text(currentFileCount);
        
        // 添加淡入動畫
        fileButton.addClass('animate__animated animate__fadeInRight');
        
        console.log(`✅ 已添加檔案導航按鈕: ${fileName} 到模組 ${moduleName}`);
    }
    
    // 更新該檔案的匹配數量
    setTimeout(() => {
        updateFileMatchCount(moduleId, fileName);
    }, 100);
}

function updateFileMatchCount(moduleId, fileName) {
    const fileButtonId = `file-btn-${moduleId}-${fileName.replace(/[^\w]/g, '-')}`;
    const fileElement = $(`#module-files-${moduleId}`).find('.result-file').filter(function() {
        return $(this).find('h6 a').text().trim() === fileName;
    });
    
    if (fileElement.length > 0) {
        const matchCountText = fileElement.find('.file-match-count').text();
        const matchCount = matchCountText.match(/\d+/);
        if (matchCount) {
            $(`#badge-${fileButtonId}`).text(matchCount[0]);
        }
    }
}

function scrollToFileInModule(moduleId, fileName) {
    const moduleContainer = $(`#module-files-${moduleId}`);
    const fileElement = moduleContainer.find('.result-file').filter(function() {
        return $(this).find('h6 a').text().trim() === fileName;
    });
    
    if (fileElement.length > 0) {
        $('html, body').animate({
            scrollTop: fileElement.offset().top - 100
        }, 500);
        
        // 添加高亮效果
        fileElement.addClass('animate__animated animate__pulse');
        setTimeout(() => {
            fileElement.removeClass('animate__animated animate__pulse');
        }, 1000);
        
        console.log(`🎯 跳轉到模組 ${moduleId} 中的檔案: ${fileName}`);
    }
}

function createStreamFileElement(data, moduleId, fileId) {
    const fileName = data.file.split('/').pop();
    
    const fileElement = $(`
        <div class="result-file animate__animated animate__fadeInUp" id="file-${moduleId}-${fileId}">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="flex-grow-1">
                    <h6 class="mb-1">
                        <a href="/view_file?path=${encodeURIComponent(data.file)}&line=1" 
                           class="file-path-link" target="_blank" title="檢視完整檔案">
                            <span class="icon-no-wrap">
                                <i class="fas fa-file"></i>${fileName}
                            </span>
                        </a>
                    </h6>
                    <small class="text-muted">${data.file}</small>
                    <span class="badge bg-light text-dark ms-2 file-match-count">0 條匹配</span>
                </div>
                <button class="btn btn-back-to-top btn-sm" onclick="scrollToModule('${data.module}')" title="回到模組頂部">
                    <span class="icon-no-wrap">
                        <i class="fas fa-arrow-up"></i>模組
                    </span>
                </button>
            </div>
            <div class="keyword-groups" id="keyword-groups-${moduleId}-${fileId}">
                <!-- 關鍵字分組將在這裡顯示 -->
            </div>
        </div>
    `);
    
    return fileElement;
}

function updateStreamFileContent(fileElement, data) {
    const moduleId = data.module.replace(/\s+/g, '-');
    const fileId = data.file.replace(/[^\w]/g, '-');
    const keywordGroupsContainer = fileElement.find(`#keyword-groups-${moduleId}-${fileId}`);
    
    // 更新檔案匹配計數
    const fileMatchCount = fileElement.find('.file-match-count');
    const currentTotal = parseInt(fileMatchCount.text().match(/\d+/)[0]) + data.matches.length;
    fileMatchCount.text(`${currentTotal} 條匹配`);
    
    // 查找或創建關鍵字組
    const keywordId = data.keyword.replace(/\s+/g, '-');
    let keywordGroup = keywordGroupsContainer.find(`#keyword-group-${moduleId}-${fileId}-${keywordId}`);
    
    if (keywordGroup.length === 0) {
        keywordGroup = createKeywordGroup(data, moduleId, fileId, keywordId);
        keywordGroupsContainer.append(keywordGroup);
    }
    
    // 添加匹配行到關鍵字組
    const keywordContent = keywordGroup.find('.keyword-content');
    data.matches.forEach(match => {
        const lineElement = createMatchLineElement(match, data.file);
        keywordContent.append(lineElement);
    });
    
    // 更新關鍵字組標題
    const keywordHeader = keywordGroup.find('.keyword-header');
    const existingCount = keywordContent.find('.result-line').length;
    keywordHeader.find('.keyword-count').text(`${existingCount} 條`);
    
    // 更新模組檔案導航中的匹配數量
    const fileName = data.file.split('/').pop();
    setTimeout(() => {
        updateFileMatchCount(moduleId, fileName);
    }, 50);
}

function createKeywordGroup(data, moduleId, fileId, keywordId) {
    const keywordGroup = $(`
        <div class="keyword-group animate__animated animate__fadeInRight" id="keyword-group-${moduleId}-${fileId}-${keywordId}">
            <div class="keyword-header" onclick="toggleKeywordGroup('${moduleId}-${fileId}-${keywordId}')">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="keyword-tag">${data.keyword}</span>
                        <span class="badge bg-primary ms-2 keyword-count">0 條</span>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <button class="btn btn-outline-primary btn-sm smart-analysis-btn" 
                                onclick="event.stopPropagation(); openSmartAnalysis('${data.module}', '${data.keyword}', '${data.file}')" 
                                title="AI智能分析">
                            <span class="icon-no-wrap">
                                <i class="fas fa-brain"></i>智能分析
                            </span>
                        </button>
                        <i class="fas fa-chevron-down keyword-toggle"></i>
                    </div>
                </div>
            </div>
            <div class="keyword-content">
                <!-- 匹配行將在這裡顯示 -->
            </div>
        </div>
    `);
    
    return keywordGroup;
}

function createMatchLineElement(match, filePath) {
    const highlightedContent = highlightKeyword(match.content, match.keyword);
    
    const lineElement = $(`
        <div class="result-line animate__animated animate__fadeIn">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <small class="text-muted mb-1">
                        <a href="/view_file?path=${encodeURIComponent(filePath)}&line=${match.line_number}" 
                           class="line-number-link" target="_blank" title="跳轉到第 ${match.line_number} 行">
                            <span class="icon-no-wrap">
                                <i class="fas fa-map-marker-alt"></i>第 ${match.line_number} 行
                            </span>
                        </a>
                    </small>
                    <div class="line-content">${highlightedContent}</div>
                </div>
            </div>
        </div>
    `);
    
    return lineElement;
}

function toggleKeywordGroup(groupId) {
    const group = $(`#keyword-group-${groupId}`);
    group.toggleClass('collapsed');
    
    const toggle = group.find('.keyword-toggle');
    if (group.hasClass('collapsed')) {
        toggle.removeClass('fa-chevron-down').addClass('fa-chevron-right');
    } else {
        toggle.removeClass('fa-chevron-right').addClass('fa-chevron-down');
    }
}

function openSmartAnalysis(module, keyword, filePath) {
    console.log('🧠 開啟智能分析:', module, keyword, filePath);
    
    try {
        // 構建智能分析URL
        const analysisUrl = `/smart_analysis?module=${encodeURIComponent(module)}&keyword=${encodeURIComponent(keyword)}&file=${encodeURIComponent(filePath)}`;
        
        // 在新視窗中開啟智能分析
        const analysisWindow = window.open(
            analysisUrl + '#loading', 
            `smart_analysis_${Date.now()}`,
            'width=1200,height=800,scrollbars=yes,resizable=yes,toolbar=no,menubar=no,location=no'
        );
        
        // 檢查是否成功開啟視窗
        if (!analysisWindow) {
            // 瀏覽器阻止了彈出視窗，使用當前頁面開啟
            showAlert('⚠️ 彈出視窗被阻止，將在當前頁面開啟智能分析', 'warning');
            setTimeout(() => {
                window.open(analysisUrl, '_blank');
            }, 1000);
        } else {
            // 成功開啟新視窗
            showAlert('🧠 正在開啟 AI 智能分析...', 'info');
            
            // 播放通知音效
            playNotificationSound('discovery');
            
            // 聚焦到新視窗
            setTimeout(() => {
                try {
                    analysisWindow.focus();
                } catch (e) {
                    console.log('無法聚焦到新視窗');
                }
            }, 500);
        }
        
        // 記錄分析事件
        logAnalysisEvent(module, keyword, filePath);
        
    } catch (e) {
        console.error('❌ 開啟智能分析失敗:', e);
        showAlert('❌ 開啟智能分析失敗，請稍後再試', 'danger');
    }
}

function logAnalysisEvent(module, keyword, filePath) {
    // 記錄分析事件，用於後續的使用統計
    const event = {
        timestamp: new Date().toISOString(),
        module: module,
        keyword: keyword,
        file: filePath,
        user_agent: navigator.userAgent
    };
    
    // 可以發送到後端進行記錄
    console.log('📊 智能分析事件記錄:', event);
    
    // 這裡可以添加發送到後端的邏輯
    // $.post('/api/log_analysis_event', event);
}

function updateModuleComplete(data) {
    const moduleId = data.module.replace(/\s+/g, '-');
    const moduleInfo = $(`#module-info-${moduleId}`);
    
    // 更新狀態為已完成
    moduleInfo.find('.analysis-status-text').html(`
        <span class="icon-no-wrap">
            <i class="fas fa-check-circle text-success"></i>完成 (${data.search_time.toFixed(2)}秒)
        </span>
    `);
    
    // 更新完成模組計數
    const completedModules = $('#stream-results .result-module').length;
    animateNumber('#stat-modules', `${completedModules}/${Object.keys(keywords).length}`);
}

function handleAnalysisComplete(data) {
    console.log('🎉 分析完成:', data);
    
    // 關閉 EventSource
    if (eventSource) {
        eventSource.close();
        eventSource = null;
    }
    
    // 更新統計
    animateNumber('#stat-time', `${data.total_time.toFixed(1)}s`);
    
    // 隱藏分析模態框
    setTimeout(() => {
        analysisModal.hide();
    }, 2000);
    
    // 創建快速導航
    createQuickNavigation();
    
    // 顯示浮動導航按鈕
    $('#floating-nav-btn').show();
    
    // 播放完成音效
    playNotificationSound('complete');
    
    // 顯示完成訊息
    showAlert(`🎉 分析完成！總共找到 ${data.total_matches || 0} 次匹配，耗時 ${data.total_time?.toFixed(2) || 0} 秒`, 'success');
    
    // 清理分析狀態
    currentAnalysisId = null;
}

function handleAnalysisError(data) {
    console.error('❌ 分析錯誤:', data);
    
    // 關閉 EventSource
    if (eventSource) {
        eventSource.close();
        eventSource = null;
    }
    
    // 隱藏分析模態框
    analysisModal.hide();
    
    // 顯示錯誤訊息
    showAlert(`❌ 分析過程中發生錯誤：${data.message || '未知錯誤'}`, 'danger');
    
    // 清理分析狀態
    currentAnalysisId = null;
}

function stopStreamAnalysis() {
    console.log('⏹️ 手動停止分析，當前分析ID:', currentAnalysisId);
    
    try {
        // 關閉 EventSource
        if (eventSource) {
            console.log('🔌 關閉 EventSource 連接');
            eventSource.close();
            eventSource = null;
        }
        
        // 清理分析資料
        if (currentAnalysisId) {
            console.log('🧹 清理分析資料:', currentAnalysisId);
            $.ajax({
                url: `/api/analysis_cleanup/${currentAnalysisId}`,
                method: 'DELETE',
                timeout: 5000
            }).done(function(response) {
                console.log('✅ 分析資料清理完成:', response);
            }).fail(function(xhr, status, error) {
                console.error('❌ 清理分析資料失敗:', status, error);
            });
            
            currentAnalysisId = null;
        }
        
        // 隱藏分析模態框
        if (analysisModal) {
            console.log('📋 關閉分析模態框');
            analysisModal.hide();
        }
        
        // 更新UI狀態
        updateProgressStatus('⏹️ 分析已停止', '用戶手動停止分析');
        
        showAlert('⏹️ 分析已手動停止', 'warning');
        
    } catch (e) {
        console.error('❌ 停止分析時發生錯誤:', e);
        showAlert('❌ 停止分析時發生錯誤', 'danger');
    }
}

function createQuickNavigation() {
    const quickNav = $('#quick-navigation');
    const moduleNavButtons = $('#module-nav-buttons');
    const fileNavButtons = $('#file-nav-buttons');
    
    // 清空現有導航
    moduleNavButtons.empty();
    fileNavButtons.empty();
    
    // 只創建模組導航，檔案導航放在各個模組內部
    $('#stream-results .result-module').each(function() {
        const moduleTitle = $(this).find('h4').text().trim();
        const moduleId = $(this).attr('id');
        const matchCount = $(this).find('.match-count').text();
        
        const moduleBtn = $(`
            <button class="btn nav-btn nav-btn-module btn-sm" onclick="scrollToModule('${moduleTitle}')">
                <span class="icon-no-wrap">
                    <i class="fas fa-cube"></i>${moduleTitle}
                </span>
                <span class="badge bg-light text-dark ms-1">${matchCount}</span>
            </button>
        `);
        moduleNavButtons.append(moduleBtn);
    });
    
    // 隱藏檔案導航區塊，因為檔案導航現在在各模組內部
    $('#file-navigation').hide();
    
    // 顯示快速導航（只包含模組導航）
    if (moduleNavButtons.children().length > 0) {
        quickNav.show();
    }
}

function scrollToModule(moduleTitle) {
    const moduleElement = $('#stream-results .result-module').filter(function() {
        return $(this).find('h4').text().trim() === moduleTitle;
    });
    
    if (moduleElement.length > 0) {
        $('html, body').animate({
            scrollTop: moduleElement.offset().top - 100
        }, 500);
        
        // 添加高亮效果
        moduleElement.addClass('animate__animated animate__pulse');
        setTimeout(() => {
            moduleElement.removeClass('animate__animated animate__pulse');
        }, 1000);
        
        console.log(`🎯 跳轉到模組: ${moduleTitle}`);
    }
}

function toggleNavigation() {
    const quickNav = $('#quick-navigation');
    const navToggleBtn = $('#nav-toggle-btn');
    
    if (quickNav.is(':visible')) {
        quickNav.slideUp(300);
        navToggleBtn.html('<i class="fas fa-compass me-1"></i>顯示導航');
    } else {
        quickNav.slideDown(300);
        navToggleBtn.html('<i class="fas fa-times me-1"></i>隱藏導航');
    }
}

function scrollToNavigation() {
    const quickNav = $('#quick-navigation');
    if (quickNav.length > 0) {
        if (!quickNav.is(':visible')) {
            toggleNavigation();
        }
        $('html, body').animate({
            scrollTop: quickNav.offset().top - 100
        }, 500);
    }
}

function animateNumber(selector, newValue) {
    const element = $(selector);
    const isNumeric = !isNaN(newValue) && newValue !== '';
    
    if (isNumeric) {
        const oldValue = parseInt(element.text()) || 0;
        const targetValue = parseInt(newValue);
        
        if (targetValue > oldValue) {
            // 添加脈衝動畫
            element.addClass('number-pulse');
            
            // 數字計數動畫
            $({ counter: oldValue }).animate({ counter: targetValue }, {
                duration: 800,
                easing: 'easeOutQuart',
                step: function() {
                    element.text(Math.ceil(this.counter));
                },
                complete: function() {
                    element.text(targetValue);
                    setTimeout(() => {
                        element.removeClass('number-pulse');
                    }, 500);
                }
            });
        }
    } else {
        element.text(newValue);
    }
}

function highlightKeyword(text, keyword) {
    if (!text || !keyword) return text;
    
    // 轉義特殊字符
    const escapedKeyword = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedKeyword})`, 'gi');
    
    return text.replace(regex, '<span class="keyword-highlight">$1</span>');
}

function playNotificationSound(type) {
    if (!audioContext) return;
    
    try {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        // 不同類型的音效
        const soundMap = {
            'success': { freq: 800, duration: 0.2 },
            'start': { freq: 600, duration: 0.3 },
            'discovery': { freq: 900, duration: 0.15 },
            'match': { freq: 1000, duration: 0.1 },
            'complete': { freq: [800, 1000, 1200], duration: 0.5 }
        };
        
        const sound = soundMap[type] || soundMap['success'];
        
        if (Array.isArray(sound.freq)) {
            // 播放和弦
            sound.freq.forEach((freq, index) => {
                setTimeout(() => {
                    const osc = audioContext.createOscillator();
                    const gain = audioContext.createGain();
                    
                    osc.connect(gain);
                    gain.connect(audioContext.destination);
                    
                    osc.frequency.value = freq;
                    osc.type = 'sine';
                    
                    gain.gain.setValueAtTime(0.1, audioContext.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
                    
                    osc.start(audioContext.currentTime);
                    osc.stop(audioContext.currentTime + 0.3);
                }, index * 0.1);
            });
        } else {
            oscillator.frequency.value = sound.freq;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + sound.duration);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + sound.duration);
        }
    } catch (e) {
        console.log('🔇 播放音效失敗:', e);
    }
}

function showAlert(message, type) {
    const alertContainer = $('#alert-container');
    const alert = $(`
        <div class="alert alert-${type} alert-dismissible fade show animate__animated animate__fadeInDown" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `);
    
    alertContainer.empty().append(alert);
    
    // 自動消失
    setTimeout(() => {
        alert.alert('close');
    }, 5000);
}

function exportResults() {
    showAlert('🔄 匯出功能開發中...', 'info');
}

function scrollToTop() {
    $('html, body').animate({
        scrollTop: 0
    }, 500);
}

function addCustomStyles() {
    if ($('#custom-enhanced-styles').length > 0) {
        return; // 已經載入過樣式
    }
    
    const styles = `
        <style id="custom-enhanced-styles">
        /* 匹配項目樣式 */
        .match-item {
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 8px;
            border-left: 3px solid #667eea;
            transition: all 0.2s ease;
        }
        
        .match-item:hover {
            background: rgba(255,255,255,0.2);
            transform: translateX(5px);
        }
        
        .match-content {
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            margin-top: 5px;
        }
        
        /* 流式結果樣式 */
        .stream-results {
            min-height: 200px;
        }
        
        .module-files {
            margin-top: 15px;
        }
        
        /* jQuery easing */
        .ui-effects-transfer {
            border: 2px dotted #667eea;
        }
        
        /* 關鍵字組動畫 */
        .keyword-group.collapsed .keyword-content {
            animation: slideUp 0.3s ease-out;
        }
        
        .keyword-group:not(.collapsed) .keyword-content {
            animation: slideDown 0.3s ease-out;
        }
        
        @keyframes slideUp {
            from { opacity: 1; max-height: 500px; }
            to { opacity: 0; max-height: 0; }
        }
        
        @keyframes slideDown {
            from { opacity: 0; max-height: 0; }
            to { opacity: 1; max-height: 500px; }
        }
        
        /* 進度動畫增強 */
        .analysis-progress .card {
            transition: all 0.3s ease;
        }
        
        .analysis-progress .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        
        /* 匹配流樣式 */
        .match-stream {
            max-height: 300px;
            overflow-y: auto;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 10px;
            background: #f8f9fa;
        }
        
        /* 響應式優化 */
        @media (max-width: 576px) {
            .keyword-header {
                padding: 8px 12px;
            }
            
            .keyword-content {
                padding: 10px 12px;
            }
            
            .match-item {
                padding: 8px;
                margin-bottom: 6px;
            }
            
            .floating-actions {
                bottom: 15px;
                right: 15px;
            }
        }
        </style>
    `;
    
    $('head').append(styles);
    
    // 添加 jQuery UI easing
    if (typeof $.easing.easeOutQuart === 'undefined') {
        $.easing.easeOutQuart = function (x, t, b, c, d) {
            return -c * ((t=t/d-1)*t*t*t - 1) + b;
        };
    }
    
    console.log('🎨 自定義樣式已載入');
}